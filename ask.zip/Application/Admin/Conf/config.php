<?php
return array(
	//'配置项'=>'配置值'
    'LAYOUT_ON'             =>  true, // 是否启用布局	
    'LAYOUT_NAME'           =>  'Layout/layout', // 当前布局名称 默认为layout

   // 'SHOW_PAGE_TRACE'       =>  true, //注意，Trance开启后，日志会被关闭
	
	


);