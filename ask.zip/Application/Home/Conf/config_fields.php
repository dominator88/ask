<?php
return array(
	'COM_SOURCE_FIELD' =>array('[03]','[04]','[06]','[07]','[13]','[15]','[16]','[17]','[18]','[28]',
							'[055]','[1611]','[1612]','[1613]','[1621]','[1622]','[1623]','[1631]','[1632]','[1633]',
							'[Q0001]','[Q0002]','[Q0003]',
							'[Q0004]','[Q0005]','[Q00151]'),
	'COM_TARGET_FIELD' =>array('$fddbr','$dianhua','$qydm','$yzbm','$hydm','$qmcyrs','$zyjjzb0','$zyjjzb1','$zyjjzb2','$shxydm',
								'$dwszd4','$zyywhd0','$zyywhd1','$zyywhd2','$zyywhd3','$zyywhd4','$zyywhd5','$zyywhd6','$zyywhd7','$zyywhd8',
								'$sfck','$sfss','$djzclx',
								'$sfgykg','$dwgm','$zw'
								
								),
	'Q_SOURCE_FIELD' =>	array('[Q0001]','[Q0002]','[Q0003]','[Q0004]','[Q0005]','[Q0006]','[Q0007]','[Q0008]','[Q0011]','[Q0012]',
							'[Q0013]','[Q0014]','[Q0015]','[Q0016]','[Q0017]','[Q0019]','[Q0023]','[Q002091]','[Q00209]','[Q00091]',
							'[Q00101]'),	
	'Q_TARGET_FIELD' => array('$now83','$now84','$now85','$now86','$now87','$now88','$now89','$now90','$now93','$now94',
							'$now95','$now97','$now98','$now99','$now100','$now102','$now92','$nowothertext103','$nowother103','$now911',
							'$now912'),
);