<?php if (!defined('THINK_PATH')) exit();?>﻿
<meta charset="utf-8">
<table  style="font-size:12px!important" class="am-table am-table-bordered" id="shengcha2">
<tr class="am-primary">
<th class="am-text-center">序号</th>
<th  class="am-text-center">类型</th>
<th  class="am-text-center">题号</th>
<th>说明</th>
<th>澄清说明</th>
</tr>

<?php if(is_array($outmsg)): foreach($outmsg as $key=>$out): ?><tr  class="am-warning">
<td  class="am-text-center"><?php echo ($key+1); ?></td>
<td  class="am-text-center"><?php echo ($out["type"]); ?></td>
<td  class="am-text-center"><?php echo ($out["num"]); ?></td>
<td><?php echo ($out["msg"]); ?></td>
<td><?php if($out['type']=='提示' || $out['type']=='警告'): ?><input id="<?php echo ($out["code"]); ?>" type="text" onchange="shuoming($(this))" value="<?php echo ($remarks[$out[code]]); ?>"  placeholder="填写的文字大于6个" size=50 /><?php endif; ?></td>
</tr><?php endforeach; endif; ?>
</table>

<script>
$(function(){

	

})

</script>