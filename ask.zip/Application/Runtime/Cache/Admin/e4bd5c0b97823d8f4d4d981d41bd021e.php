<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
    <head>        
        <title>问卷后台管理</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/ui-frame/ui.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/dropzone/dropzone.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Css/Admin-default.css" />
        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-2.1.1.min.js"></script>
    </head>


    <body>
        <div class="page-container">         
            <div class="page-sidebar">
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="<?php echo U('Index/index');?>">问卷系统后台</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li> 
				<li class="xn-openable  <?php if($umark=='anno'): ?>active<?php endif; ?>">
					<a href="<?php echo U('Announcement/index');?>"><span class="fa fa-bars"></span> <span class="xn-text"> 公告管理 </span></a>
				 </li>			
				<li class="xn-openable <?php if($umark=='company'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">企业管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Users/all');?>"><span class="fa fa-list-ul"></span>企业用户</a></li>
                        	<li><a href="<?php echo U('Users/userImport');?>"><span class="fa fa-bar-chart-o"></span>企业用户导入</a></li>
							<li><a href="<?php echo U('Class/index');?>"><span class="fa fa-bar-chart-o"></span>行业列表</a></li>
                        </ul>
                    </li>					
                    <li class="xn-openable <?php if($umark=='questionnaire'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-files-o"></span> <span class="xn-text">问卷管理</span></a>
						 <ul>
							<li><a href="<?php echo U('Questionnaire/index');?>"><span class="fa fa-files-o"></span>问卷列表</a></li>
                        	<!--li><a href="<?php echo U('Questionnaire/type');?>"><span class="fa fa-files-o"></span>问卷分类</a></li-->
                        	<!--li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li-->
                        </ul>
                    </li>                                        
                    <!--li class="xn-openable">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">回答管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Reply/all');?>"><span class="fa fa-list-ul"></span>成绩表</a></li>
                        	<li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li>
                        </ul>
                    </li-->
                    <?php if(defined("IS_ROOT")): ?><!--li><a href="<?php echo U('Wechat/distribute');?>"><span class="fa fa-comments-o"></span>群发问卷</a></li-->

                        <!--li><a href="<?php echo U('System/config');?>"><span class="fa fa-cogs"></span>系统配置</a></li--><?php endif; ?>                                        
                </ul>
            </div>
            
            <div class="page-content">
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>

                    <li class="xn-icon-button pull-right last">
                        <a href="#"><span class="fa fa-caret-down"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span>注销</a></li>
                        </ul>                        
                    </li>                     

                    <li class="pull-right"><a>欢迎你， <?php echo ($authName); ?></a></li>                    
                </ul>
                
                <ul class="breadcrumb">
                    <li><span class="fa fa-home"></span> <a href="<?php echo U('Index/index');?>">问卷系统后台</a></li>
                    <?php if(is_array($breadcrumb)): $i = 0; $__LIST__ = $breadcrumb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if((count($breadcrumb)) != $i): ?><li><a href="<?php echo ($item["path"]); ?>"><?php echo ($item["name"]); ?></a></li>
                        <?php else: ?>
                            <li class="active"><?php echo ($item["name"]); ?></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>

                </ul>
                                
                <div class="page-content-wrap">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-body"> 
<form action="<?php echo U('Admin/Questionnaire/usersDetail',array('id'=>I('id')));?>" method="post">
	 <div class="table-tools">
        <input type="radio" name="status" class="btn btn-primary" title="已提交" onClick="javascript:gohref(1);" value="1" <?php if(I('status')==1): ?>checked<?php endif; ?>/><i class="glyphicon">已提交(<?php echo ($count["submitcount"]); ?>)</i> 
        <input type="radio" name="status"  class="btn btn-primary" title="未提交" onClick="javascript:gohref(0);" value="0"  <?php if(I('status')==0): ?>checked<?php endif; ?>/><i class="glyphicon">未提交(<?php echo ($count["nosubmitcount"]); ?>)</i><i class="glyphicon">应报数(<?php echo ($count[nosubmitcount]+$count[submitcount]); ?>) </i>
		<select>
		 <?php if(is_array($season)): foreach($season as $key=>$date): ?><option value="<?php echo ($date); ?>"><?php echo ($date); ?></option><?php endforeach; endif; ?>
		</select>
		<span><input type="text" name="zzjgdm" placeholder="组织机构代码"/></span>
		<span><input type="text" name="dwxxmc" placeholder="单位名称"/></span>
		<span><button>搜索</button></span>
		<a href="<?php echo U('Admin/Questionnaire/exportList');?>">导出为csv</a>
    </div>
</form>	
    <table id="reply-table" class="table table-striped table-hover table-condensed datatable">
        <thead>
        <tr>
            <th> ID</th>
            <th>用户名</th>
			<th>单位名称</th>
            <th>真实姓名</th>
          
            <th>电话</th>
            <th>分机号</th>
            <th>手机号</th>
			<th>统计从业资格证号</th>
			
			<th>状态</th>
			<th>提示信息</th>
			<th>是否验收</th>
			<th>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php if(is_array($userList)): $i = 0; $__LIST__ = $userList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($i % 2 );++$i;?><tr>
                <td>  <?php echo ($user["id"]); ?></td>
                
                <td><?php echo ($user["username"]); ?></td>
				<td><?php echo ($user["dwmc"]); ?></td>
                <td><?php echo ($user["realname"]); ?></td>
              
                <td><?php echo ($user["telephone"]); ?></td>
				<td><?php echo ($user["subphone"]); ?></td>
				<td><?php echo ($user["mobilephone"]); ?></td>
				<td><?php echo ($user["tjcyzgzh"]); ?></td>
				
				<td><?php if($user[status]==2): ?>已提交<?php elseif($user[status]==1): ?>已保存<?php else: ?>未提交<?php endif; ?></td>
          <td><?php if($user[rcontent] != ''): ?>有<?php else: ?>无<?php endif; ?></td>
		<td>
		<?php if($user[status]==2): if($user['sfcy']==0): ?><a href="javascript:disp_confirm(<?php echo ($user[rid]); ?>)">验收</a><?php else: ?>已验收<?php endif; ?>
		<?php else: ?>
		未提交<?php endif; ?>
		</td>
			   <td>
			   <?php if($user[rid]!=''): ?><span class=" fa-times"><a href="<?php echo U('Admin/Reply/info',array('questionnaireid'=>$user[questionnaire_id],'rid'=>$user[rid]));?>">查看填报结果</a></span>
                   
					<?php else: ?>
					  <span class=" fa-times">未填报</span><?php endif; ?>
                </td>
            </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
    </table>

<script type="text/javascript">



function disp_confirm(id)
  {
  var r=confirm("确定要验收吗")
  if (r==true)
    {
    location.href="/index.php/Admin/Questionnaire/replyYanshou/id/"+id;
    }
  else
    {
 //   document.write("You pressed Cancel!")
    }
  }
function gohref(status){
	location.href = "/index.php/Admin/Questionnaire/usersDetail/id/<?php echo ($_GET['id']); ?>/status/"+status;
}
</script> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        </div>

        <div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span><strong>注销?</strong></div>
                    <div class="mb-content">
                        <p>你确定要注销登录吗？</p>                    
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="<?php echo U('Admin/Auth/logout');?>" class="btn btn-success btn-lg">确定</a>
                            <button class="btn btn-default btn-lg mb-control-close">取消</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <audio id="audio-alert" src="/Public/Audios/alert.mp3" preload="auto"></audio>

        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-ui.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap.js"></script>
        <script type="text/javascript" src="/Public/Plugins/datatables/jquery-dataTables.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/plugins.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/actions.js"></script>
        <script type="text/javascript" src="/Public/Plugins/dropzone/dropzone.js"></script>
        <script type="text/javascript" src="/Public/Plugins/knob/knob.js"></script>
        <?php if(isset($extendJs)): ?><script type="text/javascript" src="/Public/Js/Admin/<?php echo ($extendJs); ?>"></script><?php endif; ?>
    </body>
</html>