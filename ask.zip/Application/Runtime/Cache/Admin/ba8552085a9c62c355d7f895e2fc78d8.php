<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
    <head>        
        <title>问卷后台管理</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/ui-frame/ui.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/dropzone/dropzone.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Css/Admin-default.css" />
        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-2.1.1.min.js"></script>
    </head>


    <body>
        <div class="page-container">         
            <div class="page-sidebar">
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="<?php echo U('Index/index');?>">问卷系统后台</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li> 
				<li class="xn-openable  <?php if($umark=='anno'): ?>active<?php endif; ?>">
					<a href="<?php echo U('Announcement/index');?>"><span class="fa fa-bars"></span> <span class="xn-text"> 公告管理 </span></a>
				 </li>			
				<li class="xn-openable <?php if($umark=='company'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">企业管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Users/all');?>"><span class="fa fa-list-ul"></span>企业用户</a></li>
                        	<li><a href="<?php echo U('Users/userImport');?>"><span class="fa fa-bar-chart-o"></span>企业用户导入</a></li>
							<li><a href="<?php echo U('Class/index');?>"><span class="fa fa-bar-chart-o"></span>行业列表</a></li>
                        </ul>
                    </li>					
                    <li class="xn-openable <?php if($umark=='questionnaire'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-files-o"></span> <span class="xn-text">问卷管理</span></a>
						 <ul>
							<li><a href="<?php echo U('Questionnaire/index');?>"><span class="fa fa-files-o"></span>问卷列表</a></li>
                        	<!--li><a href="<?php echo U('Questionnaire/type');?>"><span class="fa fa-files-o"></span>问卷分类</a></li-->
                        	<!--li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li-->
                        </ul>
                    </li>                                        
                    <!--li class="xn-openable">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">回答管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Reply/all');?>"><span class="fa fa-list-ul"></span>成绩表</a></li>
                        	<li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li>
                        </ul>
                    </li-->
                    <?php if(defined("IS_ROOT")): ?><!--li><a href="<?php echo U('Wechat/distribute');?>"><span class="fa fa-comments-o"></span>群发问卷</a></li-->

                        <!--li><a href="<?php echo U('System/config');?>"><span class="fa fa-cogs"></span>系统配置</a></li--><?php endif; ?>                                        
                </ul>
            </div>
            
            <div class="page-content">
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>

                    <li class="xn-icon-button pull-right last">
                        <a href="#"><span class="fa fa-caret-down"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span>注销</a></li>
                        </ul>                        
                    </li>                     

                    <li class="pull-right"><a>欢迎你， <?php echo ($authName); ?></a></li>                    
                </ul>
                
                <ul class="breadcrumb">
                    <li><span class="fa fa-home"></span> <a href="<?php echo U('Index/index');?>">问卷系统后台</a></li>
                    <?php if(is_array($breadcrumb)): $i = 0; $__LIST__ = $breadcrumb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if((count($breadcrumb)) != $i): ?><li><a href="<?php echo ($item["path"]); ?>"><?php echo ($item["name"]); ?></a></li>
                        <?php else: ?>
                            <li class="active"><?php echo ($item["name"]); ?></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>

                </ul>
                                
                <div class="page-content-wrap">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-body"> <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="http://apps.bdimg.com/libs/bootstrap/3.2.0/css/bootstrap.min.css">
	

</head>
<body>
	 <!-- <2016/6/15修改> s-->
	 <form action="" method="post">
                                <div class="col-xs-12 am-u-md-8 am-u-md-pull-4">
                                    
                                    <style>
                                    table input[type=text] {
                                        border: none;
                                        outline: none;
                                        border-bottom: 1px solid #333;
                                        background: transparent;
                                    }
                                    table{font-size: 12px!important;}
                                    table h3{font-size: 12px;margin: 0;padding: 0;padding-top: 5px}
                                    table label {
                                        font-size: 12px!important
                                    }
                                    table label span{margin-bottom: 5px}
                                    table tr td {
                                        border-left: 1px solid #ddd;
                                        border-right: 1px solid #ddd;
                                    }
                                    </style>
                                    <div class="am-g" style="max-width: 1100px;">
                                        <table class="table table-bordered" style="font-size: 12px">
                                            <thead>
                                                <tr>
                                                    <th colspan="2">
                                                        <h3 style="text-align: center;">企业基本情况调查表</h3>
                                                        <div class="am-fr"><small>  表    号： N131表</small>
                                                            <br>
                                                            <small> 制表机关：   国家统计局</small>
                                                            <br>
                                                            <small>     文    号： 国统字(2015)95号</small>
                                                            <br>
                                                            <small> 有效期至：   2017年1月</small>
                                                            <br>
                                                            <small> 2015年10月</small>
                                                            <br>
                                                        </div>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >01</span>单位详细名称</h3>
                                                            <label class="am-checkbox  pull-left col-xs-9" style="margin: 0">
                                                                <input class="pull-left" type="text" data-am-ucheck style="width: 100%" name="dwxxmc" value="<?php echo ($user['Company']['dwxxmc']); ?>" >
                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >02</span>组织机构代码</h3>
                                                            <label class="am-checkbox col-xs-6 " style="margin: 0">
                                                                <input class="pull-left" type="text" data-am-ucheck name="zzjgdm" value="<?php echo ($user['Company']['zzjgdm']); ?>" >
                                                            </label>
                                                        </div>
                                                        <div class="col-xs-12 tanjie">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >B</span>统一社会信用代码</h3>
                                                            <label class="am-checkbox col-xs-6 " style="margin: 0">
                                                                <input class="pull-left" type="text" name="shxydm"  value="<?php echo ($user['Company']['shxydm']); ?>"  data-am-ucheck >
                                                            </label>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >03</span> 法定代表人(单位负责人)</h3>
                                                            <label class="am-checkbox col-xs-6 " style="margin: 0">
                                                                <input class="pull-left"  name="fddbr"  value="<?php echo ($user['Company']['fddbr']); ?>" type="text" data-am-ucheck readonly>
                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >04 </span>  联系电话(含区号)</h3>
                                                            <label class="am-checkbox col-xs-6 " style="margin: 0">
                                                                <input class="pull-left"  name="dianhua"   value="<?php echo ($user['Company']['dianhua']); ?>"  type="text" data-am-ucheck readonly>
                                                            </label>
                                                        </div>
                                                    </td>
                                                    <script>
                                                    function textput(obj) {
                                                        var oVal = obj.val();
                                                        var aVal = []
                                                        var eleText = obj.closest("td").find('input[type=text]')
                                                        var eleHide = obj.closest("td").find('input[type=hidden]')
                                                        for (var i = 0; i < eleText.length; i++) {
                                                            aVal.push(eleText[i].value)
                                                        }
                                                        var json = {}
                                                        for (var i = 0; i < aVal.length; i++) {
                                                            json[i] = aVal[i]
                                                        }
                                                        eleHide.val(JSON.stringify(json))
                                                    }
													
													function textput2(obj) {
                                                        var oVal = obj.val();
														
                                                        var aVal = []
                                                        var eleText = obj.closest("tbody").find('input[type=text]')
                                                        var eleHide = obj.closest("tbody").find('input[type=hidden]')
                                                        for (var i = 0; i < eleText.length; i++) {
                                                            aVal.push(eleText[i].value)
                                                        }
                                                        var json = {}
                                                        for (var i = 0; i < aVal.length; i++) {
                                                            json[i] = aVal[i]
                                                        }
                                                        eleHide.val(JSON.stringify(json))
                                                    }
                                                    </script>
                                                </tr>
                                                <tr>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3><span class="am-badge am-badge-primary" >05</span>单位所在地</h3>
                                                            <label class="am-checkbox  pull-left col-xs-9" style="margin: 0">
                                                                <input class="pull-left" type="text" onchange="textput($(this));"  value="<?php echo ($user['Company']['dwszd'][0]); ?>"  data-am-ucheck readonly><span class="pull-left">省(自治区、直辖市)</span><br>
                                                                <input class="pull-left" type="text" onchange="textput($(this));"  value="<?php echo ($user['Company']['dwszd'][1]); ?>"  data-am-ucheck readonly><span class="pull-left">地(区、市、州、盟)</span><br>
                                                                <input class="pull-left" type="text"  onchange="textput($(this));"  value="<?php echo ($user['Company']['dwszd'][2]); ?>" data-am-ucheck readonly><span class="pull-left">县(区、市、旗)</span><br>
                                                                <input class="pull-left" type="text"  onchange="textput($(this));"  value="<?php echo ($user['Company']['dwszd'][3]); ?>" data-am-ucheck readonly><span class="pull-left">乡(镇)</span><br>
                                                                <input class="pull-left" type="text"  onchange="textput($(this));"  value="<?php echo ($user['Company']['dwszd'][4]); ?>" data-am-ucheck readonly><span class="pull-left">街(村)</span><br>
                                                                <input class="pull-left" type="text"  onchange="textput($(this));"  value="<?php echo ($user['Company']['dwszd'][5]); ?>" data-am-ucheck readonly><span class="pull-left">门牌号</span><br>
																<input type="hidden" name="dwszd" value='<?php echo (json_encode($user['Company']['dwszd'],JSON_FORCE_OBJECT)); ?>'/>
                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >06</span> 区划代码</h3>
                                                            <label class="am-checkbox col-xs-6 " style="margin: 0">
                                                               
																 <select class="pull-left" data-am-selected="{btnSize: 'sm'}" name="qydm" >
											
																  <option >所有区划代码<?php echo ($user['Company']['qydm']); ?></option>
																  <?php if(is_array($QHDM)): foreach($QHDM as $key=>$qh): ?><option value="<?php echo ($key); ?>" <?php if($key==$user['Company']['qydm']): ?>selected<?php endif; ?>><?php echo ($qh); echo ($key); ?></option><?php endforeach; endif; ?>
																  
																</select>
                                                            </label>
                                                        </div>
                                                        <div class="col-xs-12 tanjie">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >07</span> 邮政编码</h3>
                                                            <label class="am-checkbox col-xs-6 " style="margin: 0">
                                                                <input class="pull-left" type="text"   name="yzbm"  value="<?php echo ($user['Company']['yzbm']); ?>"  data-am-ucheck readonly>
                                                            </label>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >08</span> 是否有出口业务</h3>
                                                            <label class=" col-xs-3 " style="margin: 0">
                                                                <input type="radio"  name="sfck"  value="1" data-am-ucheck <?php if($user['Company']['sfck']==1): ?>checked<?php endif; ?> disabled> 是
                                                            </label>
                                                            <label class=" col-xs-3 pull-left" style="margin: 0">
                                                                <input type="radio"  name="sfck"  value="0" data-am-ucheck  <?php if($user['Company']['sfck']==2): ?>checked<?php endif; ?> disabled>否
                                                            </label>
															<input type="hidden"  name="sfck" value="<?php echo ($user['Company']['sfck']); ?>" /> 
                                                        </div>
                                                    </td>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >09 </span> 是否为上市公司</h3>
                                                            <label class=" col-xs-3 " style="margin: 0">
                                                                <input type="radio"  name="sfss"  value="1" data-am-ucheck  <?php if($user['Company']['sfss']==1): ?>checked<?php endif; ?> disabled> 是
                                                            </label>
                                                            <label class=" col-xs-3 pull-left " style="margin: 0">
                                                                <input type="radio"  name="sfss"  value="0" data-am-ucheck  <?php if($user['Company']['sfss']==2): ?>checked<?php endif; ?> disabled> 否
                                                            </label>
															<input type="hidden"  name="sfss" value="<?php echo ($user['Company']['sfss']); ?>" /> 
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <div class="col-xs-12">
                                                            <h3><span class="am-badge am-badge-primary">10</span>    登记注册类型</h3>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="110" data-am-ucheck <?php if($user[Company][djzclx]=='110'): ?>checked<?php endif; ?> disabled> 110国有
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="120" data-am-ucheck  <?php if($user[Company][djzclx]=='120'): ?>checked<?php endif; ?> disabled> 120集体
                                                            </label>
                                                            
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                               <input type="radio"  name="djzclx" value="130" data-am-ucheck <?php if($user[Company][djzclx]=='130'): ?>checked<?php endif; ?> disabled> 130股份合作
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                 <input type="radio"  name="djzclx" value="141" data-am-ucheck <?php if($user[Company][djzclx]=='141'): ?>checked<?php endif; ?> disabled> 141国有联营
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                 <input type="radio"  name="djzclx" value="142" data-am-ucheck <?php if($user[Company][djzclx]=='142'): ?>checked<?php endif; ?> disabled> 142集体联营
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="143" data-am-ucheck <?php if($user[Company][djzclx]=='143'): ?>checked<?php endif; ?> disabled> 143国有与集体联营
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                 <input type="radio"  name="djzclx" value="149" data-am-ucheck <?php if($user[Company][djzclx]=='149'): ?>checked<?php endif; ?> disabled> 149其他联营
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="151" data-am-ucheck <?php if($user[Company][djzclx]=='151'): ?>checked<?php endif; ?> disabled> 151国有独资公司
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="159" data-am-ucheck <?php if($user[Company][djzclx]=='159'): ?>checked<?php endif; ?> disabled> 159其他有限责任公司
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                 <input type="radio"  name="djzclx" value="160" data-am-ucheck <?php if($user[Company][djzclx]=='160'): ?>checked<?php endif; ?> disabled> 160股份有限公司
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                               <input type="radio"  name="djzclx" value="171" data-am-ucheck <?php if($user[Company][djzclx]=='171'): ?>checked<?php endif; ?> disabled> 171私营独资
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                               <input type="radio"  name="djzclx" value="172" data-am-ucheck <?php if($user[Company][djzclx]=='172'): ?>checked<?php endif; ?> disabled> 172私营合伙
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="173" data-am-ucheck <?php if($user[Company][djzclx]=='173'): ?>checked<?php endif; ?> disabled> 173私营有限责任公司
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                               <input type="radio"  name="djzclx" value="174" data-am-ucheck <?php if($user[Company][djzclx]=='174'): ?>checked<?php endif; ?> disabled> 174私营股份有限公司
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                 <input type="radio"  name="djzclx" value="190" data-am-ucheck <?php if($user[Company][djzclx]=='190'): ?>checked<?php endif; ?> disabled> 190其他
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                               <input type="radio"  name="djzclx" value="210" data-am-ucheck <?php if($user[Company][djzclx]=='210'): ?>checked<?php endif; ?> disabled> 210与港澳台商合资经营
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                               <input type="radio"  name="djzclx" value="220" data-am-ucheck <?php if($user[Company][djzclx]=='220'): ?>checked<?php endif; ?> disabled> 220与港澳台商合作经营
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                 <input type="radio"  name="djzclx" value="230" data-am-ucheck <?php if($user[Company][djzclx]=='230'): ?>checked<?php endif; ?> disabled> 230港澳台独资
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="240" data-am-ucheck <?php if($user[Company][djzclx]=='240'): ?>checked<?php endif; ?> disabled> 240港澳台商投资股份有限公司
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="290" data-am-ucheck <?php if($user[Company][djzclx]=='290'): ?>checked<?php endif; ?> disabled> 290其他港澳台投资
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="310" data-am-ucheck <?php if($user[Company][djzclx]=='310'): ?>checked<?php endif; ?> disabled> 310中外合资经营
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="320" data-am-ucheck <?php if($user[Company][djzclx]=='320'): ?>checked<?php endif; ?> disabled> 320中外合作经营
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="330" data-am-ucheck <?php if($user[Company][djzclx]=='330'): ?>checked<?php endif; ?> disabled> 330外资企业
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                 <input type="radio"  name="djzclx" value="340" data-am-ucheck <?php if($user[Company][djzclx]=='340'): ?>checked<?php endif; ?> disabled> 340外商投资股份有限公司
                                                            </label>
                                                            <label class=" col-xs-4 " style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="390" data-am-ucheck <?php if($user[Company][djzclx]=='390'): ?>checked<?php endif; ?> disabled> 390其他外商投资
                                                            </label>
															<input type="hidden"  name="djzclx" value="<?php echo ($user['Company']['djzclx']); ?>" /> 
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3 class="pull-left"><span class="am-badge am-badge-primary" >11</span> 是否为国有控股企业</h3>
                                                            <label class=" col-xs-3 " style="margin: 0">
                                                                 <input type="radio"  name="sfgykg" value="1"  value="" data-am-ucheck <?php if($user['Company']['sfgykg']==1): ?>checked<?php endif; ?> disabled> 是
                                                            </label>
                                                            <label class=" col-xs-3 pull-left" style="margin: 0">
                                                                 <input type="radio"  name="sfgykg" value="0"  value="" data-am-ucheck  <?php if($user['Company']['sfgykg']==2): ?>checked<?php endif; ?> disabled>否
                                                            </label>
															<input type="hidden"  name="sfgykg" value="<?php echo ($user['Company']['sfgykg']); ?>" /> 
                                                        </div>
                                                    </td>
                                                    <td class="col-xs-6">
                                                        <div class="col-xs-12">
                                                            <h3 class="pull-left col-xs-4"><span class="am-badge am-badge-primary" >12 </span> 单位规模</h3>
                                                            <label class=" col-xs-2 " style="margin: 0">
                                                               <input type="radio"  name="dwgm" value="1"  data-am-ucheck <?php if($user['Company']['dwgm']==1): ?>checked<?php endif; ?> disabled> 大型
                                                            </label>
                                                            <label class=" col-xs-2 pull-left " style="margin: 0">
                                                               <input type="radio"  name="dwgm" value="2"  data-am-ucheck  <?php if($user['Company']['dwgm']==2): ?>checked<?php endif; ?> disabled> 中型
                                                            </label>
                                                            <label class=" col-xs-2 pull-left " style="margin: 0">
                                                                <input type="radio"  name="dwgm" value="3"  data-am-ucheck  <?php if($user['Company']['dwgm']==3): ?>checked<?php endif; ?> disabled> 小型
                                                            </label>
                                                            <label class=" col-xs-2 pull-left " style="margin: 0">
                                                               <input type="radio"  name="dwgm" value="4"  data-am-ucheck  <?php if($user['Company']['dwgm']==4): ?>checked<?php endif; ?> disabled> 微型
                                                            </label>
															 <input type="hidden"  name="dwgm" value="<?php echo ($user['Company']['dwgm']); ?>" /> 
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <div class="col-xs-12">
                                                            <h3 class="col-xs-3 pull-left"><span class="am-badge am-badge-primary">13</span>        行业代码（统计机构填写）</h3>
                                                            <label class=" col-xs-9 pull-left" style="margin: 0">
                                                                <input type="text" id="hydm"   name="hydm" value="<?php echo ($user['Company']['hydm']); ?>" data-am-ucheck >
																<select id="sheng" am-u-sm-3 am-fl"  data-am-selected  >
                                                    <option value="0">--请选择--</option>
                                                </select>
                                                <select id='shi' data-am-selected>
                                                    <option value="0">--请选择--</option>
                                                </select>
                                                            </label>
															<script type="text/javascript">
															var areaData = {
	'sheng': <?php echo ($parentstr); ?>,

    'shi': {
        <?php echo ($substr); ?>
    }
};
															
                                        $(function() {

                                            var sheng = areaData.sheng;
                                            var $sheng = $('#sheng');
                                            var $shi = $('#shi');
                                            var $xian = $('#xian');
                                            var shiIndex = 0;
                                            var sb = '';
                                            var str='';
                                            for (var i = 0; i < sheng.length; i++) {
                                                for (key in sheng[i]) {
                                                    var $option = $('<option value=' + key + '>' + sheng[i][key] + '</option>');
                                                    $sheng.append($option);
                                                }
                                            }

                                            $sheng.change(function() {
                                                shiIndex = this.selectedIndex - 1;
                                                if (shiIndex < 0) {

                                                } else {
                                                    var shi = areaData.shi['a_' + shiIndex];
                                                    $shi.html('<option value="0">--请选择--</option>');
                                                    $xian.html('<option value="0">--请选择--</option>');
                                                    for (var i = 0; i < shi.length; i++) {
                                                        for (key2 in shi[i]) {
                                                            var $option = $('<option value=' + key2 + '>' + shi[i][key2] + '</option>');
                                                            $shi.append($option);
                                                        }
                                                    }
                                                }

                                                sb = $("#sheng").find('option').eq(this.selectedIndex).val()
                                                str=$("#sheng").find('option').eq(this.selectedIndex).html()

                                            });
                                            $shi.change(function() {

                                                var sss = $("#shi").find('option').eq(this.selectedIndex).val()
                                                var sstr=$("#shi").find('option').eq(this.selectedIndex).html()
                                                // 最后提交的参数代码在subhangye隐藏表单的value和data—str里

                                                $("#hydm").val( ''+ sss)
                                                $("#hydm").attr('data-str', str+","+sstr);
                                            });


                                            

                                        });
                                        </script>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <div class="col-xs-12">
                                                            <h3 class="col-xs-2 pull-left"><span class="am-badge am-badge-primary">14</span>            从业人员期末人数</h3>
                                                            <label class=" col-xs-10 pull-left" style="margin: 0">
                                                                 <input type="text"  name="qmcyrs"   value="<?php echo ($user['Company']['qmcyrs']); ?>"  data-am-ucheck readonly>
                                                            </label>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <div class="col-xs-12">
                                                            <h3 class="col-xs-12 pull-left"><span class="am-badge am-badge-primary">15</span>            主要经济指标（不保留小数位）</h3>
                                                            <label class=" col-xs-4 pull-left" style="margin: 0">
                                                                营业收入
                                                                 <input type="text" value="<?php echo ($user['Company']['zyjjzb'][0]); ?>"   onchange="textput($(this));"  data-am-ucheck readonly>千元
                                                            </label>
                                                            <label class=" col-xs-4 pull-left" style="margin: 0">
                                                                其中：主营业务收入
                                                                <input type="text" value="<?php echo ($user['Company']['zyjjzb'][1]); ?>"   onchange="textput($(this));" data-am-ucheck readonly>千元
                                                            </label>
                                                            <label class=" col-xs-4 pull-left" style="margin: 0">
                                                                资产总计
                                                                <input type="text"    value="<?php echo ($user['Company']['zyjjzb'][2]); ?>"   onchange="textput($(this));"  data-am-ucheck readonly>千元
                                                            </label>
															<input type="hidden" name="zyjjzb" value='<?php echo (json_encode($user["Company"]["zyjjzb"],JSON_FORCE_OBJECT)); ?>'/>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <div class="col-xs-12">
                                                            <h3 class="col-xs-12 pull-left"><span class="am-badge am-badge-primary">16</span>               主要业务活动(填写营业收入份额最大的三项业务活动或主要产品，营业收入所占份额不保留小数)</h3>
                                                            <table class="table table-bordered" width="100%">
                                                                <thead>
                                                                    <tr>
                                                                        <th>业务活动(或主要产品)名称</th>
                                                                        <th>行业代码</th>
                                                                        <th>营业收入所占份额约为(%)</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <tr>
                                                                        <td>
                                                                             <input type="text"  value="<?php echo ($user['Company']['zyywhd'][0]); ?>"   onchange="textput2($(this));"  readonly/>
                                                                        </td>
                                                                        <td>
                                                                           <input type="text" value="<?php echo ($user['Company']['zyywhd'][1]); ?>"  onchange="textput2($(this));"  readonly/>
                                                                        </td>
                                                                        <td>
                                                                             <input type="text" value="<?php echo ($user['Company']['zyywhd'][2]); ?>"  onchange="textput2($(this));"  readonly/>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <input type="text" value="<?php echo ($user['Company']['zyywhd'][3]); ?>"  onchange="textput2($(this));"  readonly/>
                                                                        </td>
                                                                        <td>
                                                                           <input type="text" value="<?php echo ($user['Company']['zyywhd'][4]); ?>"  onchange="textput2($(this));"  readonly/>
                                                                        </td>
                                                                        <td>
                                                                            <input type="text" value="<?php echo ($user['Company']['zyywhd'][5]); ?>"  onchange="textput2($(this));"  readonly/>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                             <input type="text" value="<?php echo ($user['Company']['zyywhd'][6]); ?>"  onchange="textput2($(this));" readonly/>
                                                                        </td>
                                                                        <td>
                                                                             <input type="text" value="<?php echo ($user['Company']['zyywhd'][7]); ?>"  onchange="textput2($(this));"  readonly/>
                                                                        </td>
                                                                        <td>
                                                                           <input type="text" value="<?php echo ($user['Company']['zyywhd'][8]); ?>"  onchange="textput2($(this));"  readonly/>
                                                                        </td>
                                                                    </tr>
																	<input type="hidden" name="zyywhd" value='<?php echo (json_encode($user['Company']['zyywhd'],JSON_FORCE_OBJECT)); ?>' />
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td colspan="2">
                                                        <div class="am-u-sm-12">
                                                            
                                                            <label class="am-radio  am-fl" style="margin: 0">
                                                                联系人姓名：
                                                                <input type="text" value="<?php echo ($user['Company']['lxrxm']); ?>"  name="lxrxm"  onchange="textput($(this));"  data-am-ucheck readonly>
                                                            </label>
                                                            <label class="am-radio  am-fl" style="margin: 0">
                                                                职务：
                                                                <input type="text" value="<?php echo ($user['Company']['zw']); ?>"  name="zw"   onchange="textput($(this));" data-am-ucheck readonly>
                                                            </label>
                                                            <label class="am-radio  am-fl" style="margin: 0">
                                                                电话：
                                                                <input type="text"   name="lxdianhua"    value="<?php echo ($user['Company']['lxdianhua']); ?>"   onchange="textput($(this));"  data-am-ucheck readonly>
                                                            </label>
															<label class="am-radio  am-fl" style="margin: 0">
                                                                报出日期：
                                                                <input type="text"    value="<?php echo ($user['Company']['updatetime']); ?>"   onchange="textput($(this));"  data-am-ucheck readonly>
                                                            </label>
															
                                                        </div>
                                                    </td>
                                                </tr>
												
                                            </tbody>
                                        </table>
										<style>
										.am-table {
  width: 100%;
  margin-bottom: 1.6rem;
  border-spacing: 0;
  border-collapse: separate;
}
.am-table > thead > tr > th,
.am-table > tbody > tr > th,
.am-table > tfoot > tr > th,
.am-table > thead > tr > td,
.am-table > tbody > tr > td,
.am-table > tfoot > tr > td {
  padding: 0.7rem;
  line-height: 1.6;
  vertical-align: top;
  border-top: 1px solid #ddd;
}
.am-table > thead > tr > th {
  vertical-align: bottom;
  border-bottom: 1px solid #ddd;
}
.am-table > caption + thead > tr:first-child > th,
.am-table > colgroup + thead > tr:first-child > th,
.am-table > thead:first-child > tr:first-child > th,
.am-table > caption + thead > tr:first-child > td,
.am-table > colgroup + thead > tr:first-child > td,
.am-table > thead:first-child > tr:first-child > td {
  border-top: 0;
}
.am-table > tbody + tbody tr:first-child td {
  border-top: 2px solid #ddd;
}
/* Bordered version */
.am-table-bordered {
  border: 1px solid #ddd;
  border-left: none;
}
.am-table-bordered > thead > tr > th,
.am-table-bordered > tbody > tr > th,
.am-table-bordered > tfoot > tr > th,
.am-table-bordered > thead > tr > td,
.am-table-bordered > tbody > tr > td,
.am-table-bordered > tfoot > tr > td {
  border-left: 1px solid #ddd;
  /*&:first-child {
          border-left: none;
        }*/
}
.am-table-bordered > tbody > tr:first-child > th,
.am-table-bordered > tbody > tr:first-child > td {
  border-top: none;
}
.am-table-bordered > thead + tbody > tr:first-child > th,
.am-table-bordered > thead + tbody > tr:first-child > td {
  border-top: 1px solid #ddd;
}

										</style>
										
										<?php echo ($user['Company']['validata']); ?>
                                    </div>
               <script>
function shuoming(){}
function setshuoming(){
	shuoming = <?php echo ($user['Company']['shuoming']); ?>;
	for(var key in shuoming){
	//	alert(key);
		$("#"+key).val(shuoming[key]);
		
		//console.log(shuoming[key]);
		}
		$("input").attr("placeholder",'');
	}

setshuoming();
</script>			   
                                    <button class="am-btn am-btn-primary">提交</button>
                                </div>
								</form>
                                <!-- <2016/6/15修改>e -->
</body>
</html> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        </div>

        <div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span><strong>注销?</strong></div>
                    <div class="mb-content">
                        <p>你确定要注销登录吗？</p>                    
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="<?php echo U('Admin/Auth/logout');?>" class="btn btn-success btn-lg">确定</a>
                            <button class="btn btn-default btn-lg mb-control-close">取消</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <audio id="audio-alert" src="/Public/Audios/alert.mp3" preload="auto"></audio>

        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-ui.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap.js"></script>
        <script type="text/javascript" src="/Public/Plugins/datatables/jquery-dataTables.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/plugins.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/actions.js"></script>
        <script type="text/javascript" src="/Public/Plugins/dropzone/dropzone.js"></script>
        <script type="text/javascript" src="/Public/Plugins/knob/knob.js"></script>
        <?php if(isset($extendJs)): ?><script type="text/javascript" src="/Public/Js/Admin/<?php echo ($extendJs); ?>"></script><?php endif; ?>
    </body>
</html>