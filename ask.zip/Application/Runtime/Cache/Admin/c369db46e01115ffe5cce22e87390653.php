<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
    <head>        
        <title>问卷后台管理</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/ui-frame/ui.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/dropzone/dropzone.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Css/Admin-default.css" />
        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-2.1.1.min.js"></script>
    </head>


    <body>
        <div class="page-container">         
            <div class="page-sidebar">
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="<?php echo U('Index/index');?>">问卷系统后台</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li> 
				<li class="xn-openable  <?php if($umark=='anno'): ?>active<?php endif; ?>">
					<a href="<?php echo U('Announcement/index');?>"><span class="fa fa-bars"></span> <span class="xn-text"> 公告管理 </span></a>
				 </li>			
				<li class="xn-openable <?php if($umark=='company'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">企业管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Users/all');?>"><span class="fa fa-list-ul"></span>企业用户</a></li>
                        	<li><a href="<?php echo U('Users/userImport');?>"><span class="fa fa-bar-chart-o"></span>企业用户导入</a></li>
							<li><a href="<?php echo U('Class/index');?>"><span class="fa fa-bar-chart-o"></span>行业列表</a></li>
                        </ul>
                    </li>					
                    <li class="xn-openable <?php if($umark=='questionnaire'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-files-o"></span> <span class="xn-text">问卷管理</span></a>
						 <ul>
							<li><a href="<?php echo U('Questionnaire/index');?>"><span class="fa fa-files-o"></span>问卷列表</a></li>
                        	<!--li><a href="<?php echo U('Questionnaire/type');?>"><span class="fa fa-files-o"></span>问卷分类</a></li-->
                        	<!--li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li-->
                        </ul>
                    </li>                                        
                    <!--li class="xn-openable">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">回答管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Reply/all');?>"><span class="fa fa-list-ul"></span>成绩表</a></li>
                        	<li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li>
                        </ul>
                    </li-->
                    <?php if(defined("IS_ROOT")): ?><!--li><a href="<?php echo U('Wechat/distribute');?>"><span class="fa fa-comments-o"></span>群发问卷</a></li-->

                        <!--li><a href="<?php echo U('System/config');?>"><span class="fa fa-cogs"></span>系统配置</a></li--><?php endif; ?>                                        
                </ul>
            </div>
            
            <div class="page-content">
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>

                    <li class="xn-icon-button pull-right last">
                        <a href="#"><span class="fa fa-caret-down"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span>注销</a></li>
                        </ul>                        
                    </li>                     

                    <li class="pull-right"><a>欢迎你， <?php echo ($authName); ?></a></li>                    
                </ul>
                
                <ul class="breadcrumb">
                    <li><span class="fa fa-home"></span> <a href="<?php echo U('Index/index');?>">问卷系统后台</a></li>
                    <?php if(is_array($breadcrumb)): $i = 0; $__LIST__ = $breadcrumb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if((count($breadcrumb)) != $i): ?><li><a href="<?php echo ($item["path"]); ?>"><?php echo ($item["name"]); ?></a></li>
                        <?php else: ?>
                            <li class="active"><?php echo ($item["name"]); ?></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>

                </ul>
                                
                <div class="page-content-wrap">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-body"> <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="http://apps.bdimg.com/libs/bootstrap/3.2.0/css/bootstrap.min.css">
	

</head>
<body>
	 <!-- <2016/6/15修改> s-->
	 <form action="" method="post">
                                <div class="col-xs-12 am-u-md-8 am-u-md-pull-4">
                                    
                                    <style>
                                    table input[type=text] {
                                        border: none;
                                        outline: none;
                                        border-bottom: 1px solid #333;
                                        background: transparent;
                                    }
                                    table{font-size: 12px!important;}
                                    table h3{font-size: 12px;margin: 0;padding: 0;padding-top: 5px}
                                    table label {
                                        font-size: 12px!important
                                    }
                                    table label span{margin-bottom: 5px}
                                    table tr td {
                                        border-left: 1px solid #ddd;
                                        border-right: 1px solid #ddd;
                                    }
                                    </style>
                                    <div class="am-g" style="max-width: 1100px;">
                             
			<form id="qform" action="<?php echo U('Home/Index/submitQuestion',array('questionnaireId'=>I('questionnaireId')));?>" method="post">
                <div class="am-g" style="max-width: 900px">
           <table class="table table-bordered table-striped table-hover ">
    <thead>
        <tr>
            <th colspan="2"><h3 style="text-align: center;">制造业采购经理调查问卷</h3>
<div class="am-fr"><small> 表    号： N241表</small><br>
<small> 制表机关：   国家统计局</small><br>
<small>     文    号： 国统字(2015)95号</small><br>
<small> 有效期至：   2017年1月</small><br>
<small> 2015年10月</small><br></div>



            </th>
           
        </tr>
    </thead>
	
    <tbody>
    <tr style="max-height: 64px;min-height:64px">
            <td class="am-u-sm-6"style="max-height: 64px;min-height: 64px" >
               <div class="am-u-sm-12 am-cf" >
                        <h3 class=" "><span class="am-badge am-badge-primary">A</span>单位详细名称</h3>                       
                        <label class="am-checkbox am-u-sm-12" style="margin: 0">
                            <input type="text"  data-am-ucheck style="width: 100%" value="<?php echo ($user["Company"]["dwxxmc"]); ?>" disabled> 
                        </label>
                       
                    </div>
            </td>
            <td class="am-u-sm-6">
            
               <div class="am-u-sm-12" >
                       
                       <h3 class="am-fl" ><span class="am-badge am-badge-primary" >B</span>组织机构代码</h3>
                        <label class="am-checkbox am-u-sm-6 " style="margin: 0">
                            <input  class="am-fl" type="text"  data-am-ucheck  value="<?php echo ($user["Company"]["zzjgdm"]); ?>" disabled> 
                        </label>
                        
                       
                    </div> 
                    <div class="am-u-sm-12 tanjie" >
                       
                        <h3 class="am-fl" >	统一社会信用代码</h3>
                        <label class="am-checkbox am-u-sm-6 " style="margin: 0">
                           <input  class="am-fl" type="text"  value="<?php echo ($user[Company][shxydm]); ?>" data-am-ucheck disabled> 
                        </label>
                        
                       
                    </div> 

            </td>
            
        </tr>
		
		 <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$d): $mod = ($i % 2 );++$i; if($d['qtype'] == 'text'): ?><tr>
             <td  colspan="2">  
			 <div class="am-u-sm-12" >
                       
                       <h3 class="am-fl" > <?php echo ($d["qname"]); ?></h3>
					
					    <?php if(is_array($d['options'])): foreach($d['options'] as $k=>$option): ?><label class="am-checkbox am-u-sm-12 " style="margin: 0">
                                <?php echo (trim($option[text])); ?><input  class="am-fl" type="text" value="<?php echo ($option[value]); ?>" name="<?php echo ($d["qid"]); ?>"  onchange="textput($(this))"  data-am-ucheck  style="width: 100%"/> 
                        </label><?php endforeach; endif; ?>
                        
                        <input type="hidden" name="<?php echo ($d["qid"]); ?>"  value='<?php echo ($d["answer"]); ?>'/> 
                       
                    </div></td> 

        </tr>
		
		 <?php elseif($d['qtype'] == 'checkbox'): ?>
        <tr >
            <td colspan="2">
               <div class="am-u-sm-12 tanjie" id="tanjei1">
                        <h3><?php echo ($d["qname"]); ?></h3>
						
                       <?php if(is_array($d['options'])): foreach($d['options'] as $k=>$option): if($option[type]=='checkbox'): ?><label class="am-checkbox am-u-sm-3" style="margin: 0">
                            <input type="checkbox" value="<?php echo ($k); ?>" name="<?php echo ($d["qid"]); ?>"  data-am-ucheck onchange="s($(this),'#id<?php echo ($d["qid"]); ?>')" <?php if($option[selected]==1): ?>checked<?php endif; ?>/>  <?php echo ($option['text']); ?>
                        </label>
                       <?php elseif($option[type]=='checkbox_othertext'): ?>
						<label class="am-checkbox am-u-sm-12 " style="margin: 0">
							  <input type="checkbox" value="<?php echo ($k); ?>" name="other<?php echo ($d["qid"]); ?>"  onchange="s($(this),'#id<?php echo ($d["qid"]); ?>')" data-am-ucheck  <?php if($option[selected]==1): ?>checked<?php endif; ?>/>  其它<input type="text" id="o_other" value="<?php echo ($option["text"]); ?>" name="othertext<?php echo ($d["qid"]); ?>" onchange="other()"/>
						</label><?php endif; endforeach; endif; ?>
                       <input type="hidden" id="id<?php echo ($d["qid"]); ?>" name="<?php echo ($d["qid"]); ?>" value='<?php echo ($d["answer"]); ?>' />

                    </div>


            </td>
            
        </tr>
        <?php elseif($d['qtype'] == 'radio'): ?>
        <tr >
            <td colspan="2">
              <div class="am-u-sm-12">
                        <h3><?php echo ($d["qname"]); ?></h3>
					
                        <?php if(is_array($d['options'])): foreach($d['options'] as $k=>$option): if($option['text'] != ''): ?><label class="am-radio am-u-sm-6 am-u-lg-3 am-u-md-6" style="margin: 0">
                            <input type="radio" name="<?php echo ($d["qid"]); ?>" value="<?php echo ($k); ?>" data-am-ucheck <?php if($option[selected]==1): ?>checked<?php endif; ?>/> <?php echo ($option['text']); ?>
                        </label><?php endif; endforeach; endif; ?>
                        
                    </div>

            </td>
            
        </tr><?php endif; endforeach; endif; else: echo "" ;endif; ?>
    </tbody>
	
</table>

<div>
采购经理(填报人)：	
<input  type="text" value="<?php echo ($user["realname"]); ?>" name="lxrxm" onchange="textput($(this))" data-am-ucheck="" style="width: 10%" disabled>
电话：	
<input  type="text" value="<?php echo ($user["telephone"]); ?>" name="lxdianhua" onchange="textput($(this))" data-am-ucheck="" style="width: 10%" disabled>
分机号：<input  type="text" value="<?php echo ($user["subphone"]); ?>" name="lxr" onchange="textput($(this))" data-am-ucheck="" style="width: 10%" disabled>	
报出日期：	
<input  type="text" value="<?php if($user[createtime]!=''): echo (date('Y-m-d',$user[createtime])); endif; ?>" name="lxr" onchange="textput($(this))" data-am-ucheck="" style="width: 10%" disabled>
 <br/>
</div>
<style>
										.am-table {
  width: 100%;
  margin-bottom: 1.6rem;
  border-spacing: 0;
  border-collapse: separate;
}
.am-table > thead > tr > th,
.am-table > tbody > tr > th,
.am-table > tfoot > tr > th,
.am-table > thead > tr > td,
.am-table > tbody > tr > td,
.am-table > tfoot > tr > td {
  padding: 0.7rem;
  line-height: 1.6;
  vertical-align: top;
  border-top: 1px solid #ddd;
}
.am-table > thead > tr > th {
  vertical-align: bottom;
  border-bottom: 1px solid #ddd;
}
.am-table > caption + thead > tr:first-child > th,
.am-table > colgroup + thead > tr:first-child > th,
.am-table > thead:first-child > tr:first-child > th,
.am-table > caption + thead > tr:first-child > td,
.am-table > colgroup + thead > tr:first-child > td,
.am-table > thead:first-child > tr:first-child > td {
  border-top: 0;
}
.am-table > tbody + tbody tr:first-child td {
  border-top: 2px solid #ddd;
}
/* Bordered version */
.am-table-bordered {
  border: 1px solid #ddd;
  border-left: none;
}
.am-table-bordered > thead > tr > th,
.am-table-bordered > tbody > tr > th,
.am-table-bordered > tfoot > tr > th,
.am-table-bordered > thead > tr > td,
.am-table-bordered > tbody > tr > td,
.am-table-bordered > tfoot > tr > td {
  border-left: 1px solid #ddd;
  /*&:first-child {
          border-left: none;
        }*/
}
.am-table-bordered > tbody > tr:first-child > th,
.am-table-bordered > tbody > tr:first-child > td {
  border-top: none;
}
.am-table-bordered > thead + tbody > tr:first-child > th,
.am-table-bordered > thead + tbody > tr:first-child > td {
  border-top: 1px solid #ddd;
}

										</style>
<?php echo ($validatacontent); ?>
<script>
var json = eval('('+'<?php echo ($remarks); ?>'+')'); 
for(j in json){
	$('#'+j).val(json[j]);
}
</script>



                </div>
                                                       
                                    </div>
                                    
                                   
                                </div>
								</form>
                                <!-- <2016/6/15修改>e -->
</body>
</html> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        </div>

        <div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span><strong>注销?</strong></div>
                    <div class="mb-content">
                        <p>你确定要注销登录吗？</p>                    
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="<?php echo U('Admin/Auth/logout');?>" class="btn btn-success btn-lg">确定</a>
                            <button class="btn btn-default btn-lg mb-control-close">取消</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <audio id="audio-alert" src="/Public/Audios/alert.mp3" preload="auto"></audio>

        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-ui.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap.js"></script>
        <script type="text/javascript" src="/Public/Plugins/datatables/jquery-dataTables.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/plugins.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/actions.js"></script>
        <script type="text/javascript" src="/Public/Plugins/dropzone/dropzone.js"></script>
        <script type="text/javascript" src="/Public/Plugins/knob/knob.js"></script>
        <?php if(isset($extendJs)): ?><script type="text/javascript" src="/Public/Js/Admin/<?php echo ($extendJs); ?>"></script><?php endif; ?>
    </body>
</html>