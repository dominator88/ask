<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
    <head>        
        <title>问卷后台管理</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/ui-frame/ui.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/dropzone/dropzone.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Css/Admin-default.css" />
        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-2.1.1.min.js"></script>
    </head>


    <body>
        <div class="page-container">         
            <div class="page-sidebar">
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="<?php echo U('Index/index');?>">问卷系统后台</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li> 
				<li class="xn-openable  <?php if($umark=='anno'): ?>active<?php endif; ?>">
					<a href="<?php echo U('Announcement/index');?>"><span class="fa fa-bars"></span> <span class="xn-text"> 公告管理 </span></a>
				 </li>			
				<li class="xn-openable <?php if($umark=='company'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">企业管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Users/all');?>"><span class="fa fa-list-ul"></span>企业用户</a></li>
                        	<li><a href="<?php echo U('Users/userImport');?>"><span class="fa fa-bar-chart-o"></span>企业用户导入</a></li>
							<li><a href="<?php echo U('Class/index');?>"><span class="fa fa-bar-chart-o"></span>行业列表</a></li>
                        </ul>
                    </li>					
                    <li class="xn-openable <?php if($umark=='questionnaire'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-files-o"></span> <span class="xn-text">问卷管理</span></a>
						 <ul>
							<li><a href="<?php echo U('Questionnaire/index');?>"><span class="fa fa-files-o"></span>问卷列表</a></li>
                        	<!--li><a href="<?php echo U('Questionnaire/type');?>"><span class="fa fa-files-o"></span>问卷分类</a></li-->
                        	<!--li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li-->
                        </ul>
                    </li>                                        
                    <!--li class="xn-openable">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">回答管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Reply/all');?>"><span class="fa fa-list-ul"></span>成绩表</a></li>
                        	<li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li>
                        </ul>
                    </li-->
                    <?php if(defined("IS_ROOT")): ?><!--li><a href="<?php echo U('Wechat/distribute');?>"><span class="fa fa-comments-o"></span>群发问卷</a></li-->

                        <!--li><a href="<?php echo U('System/config');?>"><span class="fa fa-cogs"></span>系统配置</a></li--><?php endif; ?>                                        
                </ul>
            </div>
            
            <div class="page-content">
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>

                    <li class="xn-icon-button pull-right last">
                        <a href="#"><span class="fa fa-caret-down"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span>注销</a></li>
                        </ul>                        
                    </li>                     

                    <li class="pull-right"><a>欢迎你， <?php echo ($authName); ?></a></li>                    
                </ul>
                
                <ul class="breadcrumb">
                    <li><span class="fa fa-home"></span> <a href="<?php echo U('Index/index');?>">问卷系统后台</a></li>
                    <?php if(is_array($breadcrumb)): $i = 0; $__LIST__ = $breadcrumb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if((count($breadcrumb)) != $i): ?><li><a href="<?php echo ($item["path"]); ?>"><?php echo ($item["name"]); ?></a></li>
                        <?php else: ?>
                            <li class="active"><?php echo ($item["name"]); ?></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>

                </ul>
                                
                <div class="page-content-wrap">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-body"> <form action="<?php echo U('Questionnaire/edit', array('id'=>$id));?>" method="post" class="form-horizontal">
    <input type="hidden" name="id" value="<?php echo ($id); ?>">
    <div class="form-group">
        <label class="col-md-3 col-xs-12 control-label"></label>
        <div class="col-md-6 col-xs-12">
            <h2>编辑问卷</h2>
        </div>
    </div>

    <div class="form-group">

        <label class="col-md-3 col-xs-12 control-label">问卷类型</label>
        <div class="col-md-6 col-xs-12">                                                                                            
            <select name="type" class="form-control select">
                <option value="survey" <?php if(($type) == "survey"): ?>selected="selected"<?php endif; ?> >调研卷</option>
                <!--option value="exam" <?php if(($type) == "exam"): ?>selected="selected"<?php endif; ?> >考试卷</option-->
            </select>
        </div>
        
    </div>
	
	<div class="form-group">

        <label class="col-md-3 col-xs-12 control-label">问卷别名</label>
        <div class="col-md-6 col-xs-12">                                                                                             
                                                     
            <input name="aliasname" type="text" class="form-control" value="<?php echo ($aliasname); ?>" />
        </div>
        
       
    </div>
	
	

    <div class="form-group">
        <label class="col-md-3 col-xs-12 control-label">问卷名称</label>
        <div class="col-md-6 col-xs-12">                                            
            <input name="name" type="text" class="form-control " value="<?php echo ($name); ?>" />
        </div>
    </div>
    
    <div class="form-group">
        <label class="col-md-3 col-xs-12 control-label">问卷描述</label>
        <div class="col-md-6 col-xs-12">                                            
            <textarea name="description" class="form-control" rows="10"><?php echo ($description); ?></textarea>
        </div>
    </div>
    


	
	
	
	
	
	
	
	
	
    <div class="form-group">    
		 <label class="col-md-3 col-xs-12 control-label">开始日期 ~~ 失效日期</label>
        <div class="col-md-6 col-xs-12">
            <div class="col-md-6 col-xs-12" style="width:550px">  
				<select name="start_date" class="select" style="width:70px">
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
				<option value="11">11</option>
				<option value="12">12</option>
				<option value="13">13</option>
				<option value="14">14</option>
				<option value="15">15</option>
				<option value="16">16</option>
				<option value="17">17</option>
				<option value="18">18</option>
				<option value="19">19</option>
				<option value="20">20</option>
				<option value="21">21</option>
				<option value="22">22</option>
				<option value="23">23</option>
				<option value="24">24</option>
				<option value="25">25</option>
				<option value="26">26</option>
				<option value="27">27</option>
				<option value="28">28</option>
				<option value="29">29</option>
				<option value="30">30</option>
				<option value="31">31</option>
				
				</select>
				&nbsp;~~&nbsp;
				<select name="expire_date" class="select" style="width:70px">
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
				<option value="11">11</option>
				<option value="12">12</option>
				<option value="13">13</option>
				<option value="14">14</option>
				<option value="15">15</option>
				<option value="16">16</option>
				<option value="17">17</option>
				<option value="18">18</option>
				<option value="19">19</option>
				<option value="20">20</option>
				<option value="21">21</option>
				<option value="22">22</option>
				<option value="23">23</option>
				<option value="24">24</option>
				<option value="25">25</option>
				<option value="26">26</option>
				<option value="27">27</option>
				<option value="28">28</option>
				<option value="29">29</option>
				<option value="30">30</option>
				<option value="31">31</option>
				</select>
               
            </div>
			<small>月份内不足31天,按实际天数计算</small>
        </div>
	
       
    </div>

    <div>
        <div class="col-md-3 col-xs-12"></div>
        <div class="col-md-6 col-xs-12">
            <?php if(isset($errorNote)): ?><div class="alert alert-danger" role="alert">
                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <strong><?php echo ($errorNote); ?></strong>
                </div><?php endif; ?>
            <div class="form-group">
                <div class="col-md-6"><input type="reset" class="btn btn-block btn-default" value=" 清 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 空 " /></div>
                <div class="col-md-6"><button class="btn btn-block btn-info pull-right"> 提 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 交 </button></div>
            </div>
        </div>
    </div>

</form>
 </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        </div>

        <div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span><strong>注销?</strong></div>
                    <div class="mb-content">
                        <p>你确定要注销登录吗？</p>                    
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="<?php echo U('Admin/Auth/logout');?>" class="btn btn-success btn-lg">确定</a>
                            <button class="btn btn-default btn-lg mb-control-close">取消</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <audio id="audio-alert" src="/Public/Audios/alert.mp3" preload="auto"></audio>

        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-ui.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap.js"></script>
        <script type="text/javascript" src="/Public/Plugins/datatables/jquery-dataTables.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/plugins.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/actions.js"></script>
        <script type="text/javascript" src="/Public/Plugins/dropzone/dropzone.js"></script>
        <script type="text/javascript" src="/Public/Plugins/knob/knob.js"></script>
        <?php if(isset($extendJs)): ?><script type="text/javascript" src="/Public/Js/Admin/<?php echo ($extendJs); ?>"></script><?php endif; ?>
    </body>
</html>