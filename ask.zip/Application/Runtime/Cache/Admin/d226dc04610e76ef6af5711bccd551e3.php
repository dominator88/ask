<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
    <head>        
        <title>问卷后台管理</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/ui-frame/ui.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Plugins/dropzone/dropzone.css" />
        <link rel="stylesheet" type="text/css" href="/Public/Css/Admin-default.css" />
        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-2.1.1.min.js"></script>
    </head>


    <body>
        <div class="page-container">         
            <div class="page-sidebar">
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="<?php echo U('Index/index');?>">问卷系统后台</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li> 
				<li class="xn-openable  <?php if($umark=='anno'): ?>active<?php endif; ?>">
					<a href="<?php echo U('Announcement/index');?>"><span class="fa fa-bars"></span> <span class="xn-text"> 公告管理 </span></a>
				 </li>			
				<li class="xn-openable <?php if($umark=='company'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">企业管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Users/all');?>"><span class="fa fa-list-ul"></span>企业用户</a></li>
                        	<li><a href="<?php echo U('Users/userImport');?>"><span class="fa fa-bar-chart-o"></span>企业用户导入</a></li>
							<li><a href="<?php echo U('Class/index');?>"><span class="fa fa-bar-chart-o"></span>行业列表</a></li>
                        </ul>
                    </li>					
                    <li class="xn-openable <?php if($umark=='questionnaire'): ?>active<?php endif; ?>">
                        <a><span class="fa fa-files-o"></span> <span class="xn-text">问卷管理</span></a>
						 <ul>
							<li><a href="<?php echo U('Questionnaire/index');?>"><span class="fa fa-files-o"></span>问卷列表</a></li>
                        	<!--li><a href="<?php echo U('Questionnaire/type');?>"><span class="fa fa-files-o"></span>问卷分类</a></li-->
                        	<!--li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li-->
                        </ul>
                    </li>                                        
                    <!--li class="xn-openable">
                        <a><span class="fa fa-bars"></span> <span class="xn-text">回答管理</span></a>
                        <ul>
                        	<li><a href="<?php echo U('Reply/all');?>"><span class="fa fa-list-ul"></span>成绩表</a></li>
                        	<li><a href="<?php echo U('Reply/analyze');?>"><span class="fa fa-bar-chart-o"></span>问卷分析</a></li>
                        </ul>
                    </li-->
                    <?php if(defined("IS_ROOT")): ?><!--li><a href="<?php echo U('Wechat/distribute');?>"><span class="fa fa-comments-o"></span>群发问卷</a></li-->

                        <!--li><a href="<?php echo U('System/config');?>"><span class="fa fa-cogs"></span>系统配置</a></li--><?php endif; ?>                                        
                </ul>
            </div>
            
            <div class="page-content">
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>

                    <li class="xn-icon-button pull-right last">
                        <a href="#"><span class="fa fa-caret-down"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span>注销</a></li>
                        </ul>                        
                    </li>                     

                    <li class="pull-right"><a>欢迎你， <?php echo ($authName); ?></a></li>                    
                </ul>
                
                <ul class="breadcrumb">
                    <li><span class="fa fa-home"></span> <a href="<?php echo U('Index/index');?>">问卷系统后台</a></li>
                    <?php if(is_array($breadcrumb)): $i = 0; $__LIST__ = $breadcrumb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i; if((count($breadcrumb)) != $i): ?><li><a href="<?php echo ($item["path"]); ?>"><?php echo ($item["name"]); ?></a></li>
                        <?php else: ?>
                            <li class="active"><?php echo ($item["name"]); ?></li><?php endif; endforeach; endif; else: echo "" ;endif; ?>

                </ul>
                                
                <div class="page-content-wrap">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-body"> <style type="text/css">
			* {
				margin: 0;
				padding: 0;
			}
			
			.modify,
			.add,
			.del,
			.add2 {
				padding: 5px;
				color: #fff;
				font-size: 14px;
				margin: 5px;
				cursor: pointer;
				border-radius: 5px
			}
			
			.modify {
				background: lightseagreen;
				padding: 5px;
				color: #fff;
				font-size: 14px;
			}
			
			.add,
			.add2 {
				background: palevioletred;
				padding: 5px;
				color: #fff;
				font-size: 14px;
			}
			
			.del {
				background: red;
				padding: 5px;
				color: #fff;
				font-size: 14px;
			}
			
			#tanjie-list li {
				margin: 5px;
				border: 1px solid #ddd;
				padding: 10px;
				background: #eee;
			}
			
			#tanjie-list ol li {
				background: #fff
			}
			
			#tanjie-list ul li {
				background: #eee;
			}
			
			#tanjie-add {
				padding: 10px;
				background: green;
				color: #fff;
			}
			
			ul ol li {
				list-style: none;
			}
			.t-box{padding-left: 40px;}
		</style>
		<div class="t-box">
			<div class="btn-group">
				<button type="button" id="tanjie-add">新增+</button>
			</div>
		</div>
		<div class="panel-body">

			<?php echo ($classtr); ?>

			<script type="text/javascript">
				$(function() {
					$("#tanjie-add").click(function() {
						$("#tanjie-list").append('<li><input/><span class="modify">修改</span><span class="add">添加子类</span><span class="del" id="xx">删除</span><ol></ol></li>')
					});

					$("#tanjie-list").delegate(".del", "click", function() {

						var choice = confirm("您确认要删除吗？", function() {}, null);
						if (choice) {
							$(this).parent("li").remove();
						}
					});

					$("#tanjie-list").delegate(".add", "click", function() {
						data = $(this).parent("li").find(".modify").attr('data');
						
						$(this).parent("li").find("ol").append('<li><input data="'+data+'"/><span>&nbsp;</span><input id="code"  /><span class="modify"  >修改</span><span class="add2">添加子类</span><span class="del" id="xx">删除</span><ul></ul></li>')
					})

					$("#tanjie-list").delegate(".add2", "click", function() {
						data = $(this).parent("li").find(".modify").attr('data');
						
						$(this).parent("li").find("ul").append('<li><input data="'+data+'"/><span>&nbsp;</span><input id="code"  /><span class="modify"  >修改</span><span class="del" id="xx">删除</span></li>')
					})
					
					$("#tanjie-list").delegate(".modify", "click", function() {
						id =  $(this).parent("li").find(".modify").attr('data');
						parentid = $(this).parent("li").find("input").attr('data');
						code = $(this).parent("li").find("#code").val();
						value = $(this).parent("li").find("input").val();
						
						$.post(
							'/index.php/Admin/Class/edit_ajax.html',
							{id:id,catname:value,parent_id:parentid,code:code},
							function(data){
								if(data.status == 2){
								//	$(this).parent("li").find(".modify").attr('data',data.id);
								//	console.log($(this).parent("li").find(".modify").attr('data'));
								}else{
								//console.log(data);
								}
							});
					})

				})
				//setClass();
				function setClass(){
					
				//	dataparent_id = $("#class"+id).attr('data');
				//	datacatname = $("#class"+id).val();
					id = data = $(this).parent("li").find(".modify").attr('data');
					console.log(id);
					data = $(this).parent("li").find("input[name]").attr('data');
					console.log($(this).attr('class'));
				//	console.log(datacatname);
					$.post(
						'/index.php/Admin/Class/edit_ajax.html',
							{id:id,catname:datacatname,parent_id:dataparent_id},
						function(data){
							console.log(data);
						}
					);
				}
			</script>
			<?php echo ($classstr); ?> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        </div>

        <div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span><strong>注销?</strong></div>
                    <div class="mb-content">
                        <p>你确定要注销登录吗？</p>                    
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="<?php echo U('Admin/Auth/logout');?>" class="btn btn-success btn-lg">确定</a>
                            <button class="btn btn-default btn-lg mb-control-close">取消</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <audio id="audio-alert" src="/Public/Audios/alert.mp3" preload="auto"></audio>

        <script type="text/javascript" src="/Public/Plugins/jquery/jquery-ui.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap.js"></script>
        <script type="text/javascript" src="/Public/Plugins/datatables/jquery-dataTables.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/Public/Plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/plugins.js"></script>
        <script type="text/javascript" src="/Public/Plugins/ui-frame/actions.js"></script>
        <script type="text/javascript" src="/Public/Plugins/dropzone/dropzone.js"></script>
        <script type="text/javascript" src="/Public/Plugins/knob/knob.js"></script>
        <?php if(isset($extendJs)): ?><script type="text/javascript" src="/Public/Js/Admin/<?php echo ($extendJs); ?>"></script><?php endif; ?>
    </body>
</html>