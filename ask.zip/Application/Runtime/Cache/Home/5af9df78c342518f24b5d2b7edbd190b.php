<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html class="no-js">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>问卷调查</title>
  <meta name="description" content="这是一个 table 页面">
  <meta name="keywords" content="table">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="renderer" content="webkit">
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <link rel="icon" type="image/png" href="/Public/assets/i/favicon.png">
  <link rel="apple-touch-icon-precomposed" href="/Public/assets/i/app-icon72x72@2x.png">
  <meta name="apple-mobile-web-app-title" content="Amaze UI" />
  <link rel="stylesheet" href="/Public/assets/css/amazeui.min.css"/>
  <link rel="stylesheet" href="/Public/assets/css/admin.css">
	<!--[if (gte IE 9)|!(IE)]><!-->
	<script src="/Public/assets/js/jquery.min.js"></script>
	<!--<![endif]-->
</head>
<body>
<!--[if lte IE 9]>
<p class="browsehappy">你正在使用<strong>过时</strong>的浏览器，Amaze UI 暂不支持。 请 <a href="http://browsehappy.com/" target="_blank">升级浏览器</a>
  以获得更好的体验！</p>
<![endif]-->

<header class="am-topbar am-topbar-inverse admin-header">
  <div class="am-topbar-brand">
    <strong>国家统计局武汉调查队统计平台</strong> 
  </div>

  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>

  <div class="am-collapse am-topbar-collapse" id="topbar-collapse">

    <ul class="am-nav am-nav-pills am-topbar-nav am-topbar-right admin-header-list">
      
      <li class="am-dropdown" data-am-dropdown>
        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;">
          <span class="am-icon-users"></span> <?php echo (session('USERNAME')); ?> <span class="am-icon-caret-down"></span>
        </a>
        <ul class="am-dropdown-content">
          <li><a href="<?php echo U('Home/Index/userCenter');?>"><span class="am-icon-user"></span> 资料</a></li>
          <!--li><a href="#"><span class="am-icon-cog"></span> 设置</a></li-->
          <li><a href="<?php echo U('Home/Index/logout');?>"><span class="am-icon-power-off"></span> 退出</a></li>
        </ul>
      </li>
      <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
    </ul>
  </div>
</header>

<div class="am-cf admin-main">
  <!-- sidebar start -->
  <div class="admin-sidebar " id="admin-offcanvas"><!--am-offcanvas-->
    <div class=" "><!--am-offcanvas-bar admin-offcanvas-bar-->
      <ul class="am-list admin-sidebar-list">
        <li><a href="<?php echo U('Home/Index/userCenter');?>"><span class="am-icon-home"></span> 个人中心</a></li>
		  <li><a href="<?php echo U('Home/Index/listAnnouncement');?>"><span class="am-icon-file"></span> 公告管理</a></li>
        <li class="admin-parent">
          <a class="am-cf" data-am-collapse="{target: '#collapse-nav'}"><span class="am-icon-file"></span> 我的问卷 <span class="am-icon-angle-right am-fr am-margin-right"></span></a>
          <ul class="am-list am-collapse admin-sidebar-sub am-in" id="collapse-nav">
            <li><a href="<?php echo U('/Home/Index/newQuestionnaires');?>" class="am-cf"><span class="am-icon-check"></span> 填报问卷<span class="am-icon-star am-fr am-margin-right admin-icon-yellow"></span></a></li>
            <li><a href="<?php echo U('Home/Index/historyQuestionnaires');?>"><span class="am-icon-puzzle-piece"></span> 历史问卷</a></li>
          </ul>
        </li>
         <li><a href="<?php echo U('Home/Index/help');?>"><span class="am-icon-file"></span> 帮助中心</a></li>
        <li><a href="<?php echo U('Home/Index/logout');?>"><span class="am-icon-sign-out"></span> 注销</a></li>
      </ul>

      <!--div class="am-panel am-panel-default admin-sidebar-panel">
        <div class="am-panel-bd">
          <p><span class="am-icon-bookmark"></span> 公告</p>
          <p>时光静好，与君语；细水流年，与君同。—— xx</p>
        </div>
      </div-->

     
    </div>
  </div>
  <!-- sidebar end -->

   <!-- content start -->
  <div class="admin-content">
    <div class="admin-content-body">
	<br>
      <div class="am-tabs" data-am-tabs>
     
		<ul class="am-tabs-nav am-nav am-nav-tabs">
                       
                       
                    </ul>
     <div class="am-tabs-bd">
		
	  
	  <div class="am-tab-panel am-fade  am-in am-active" id="tab2">
                           
                          
                            <div class="am-g">
                                <div class="am-u-sm-12 am-u-md-4 am-u-md-push-8">
								
                                </div>
                                <div class="am-u-sm-12 am-u-md-8 am-u-md-pull-4">
                                    
									
									
									<style>
                                    table input[type=text] {
                                        border: none;
                                        outline: none;
                                        border-bottom: 1px solid #333;
                                        background: transparent;
                                    }
                                    
                                    table label {
                                        font-size: 12px!important
                                    }
                                    
                                    table tr td {
                                        border-left: 1px solid #ddd;
                                        border-right: 1px solid #ddd;
                                    }
                                    </style>
									<form name="formCom" id="qform" action="<?php echo U('Home/Index/userCenter');?>"  method="post">
                                    <div class="am-g" style="max-width: 1100px;">
                                        <table class="am-table am-table-bordered " style="font-size: 12px">
                                            <thead>
                                                <tr>
                                                    <th colspan="2">
                                                         <h3 style="text-align: center;font-size:18px">企业基本情况调查表</h3>
                                                        <div class="am-fr"><small>  表    号： N131表</small>
                                                            <br>
                                                            <small> 制表机关：   国家统计局</small>
                                                            <br>
                                                            <small>     文    号： 国统字(2015)95号</small>
                                                            <br>
                                                            <small> 有效期至：   2017年1月</small>
                                                            <br>
                                                           
                                                            <br>
                                                        </div>
														<small style="text-align:center;width:100%;display:block" class="am-fr"> <?php echo ($user['Company'][yupdatetime]-1); ?>年</small>
                                                    </th>
                                                </tr>
                                            </thead>
											 
                                            <tbody>
                                                <tr>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >01</span>单位详细名称</h3>
                                                            <label class="am-checkbox  am-fl am-u-sm-9" style="margin: 0">
                                                                <input class="am-fl" type="text" data-am-ucheck style="width: 100%" name="dwxxmc" value="<?php echo ($user['Company']['dwxxmc']); ?>"  readonly>
                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >02</span>组织机构代码</h3>
                                                            <label class="am-checkbox am-u-sm-6 " style="margin: 0">
                                                                <input class="am-fl" type="text" name="zzjgdm" value="<?php echo ($user['Company']['zzjgdm']); ?>"  data-am-ucheck readonly>
                                                            </label>
                                                        </div>
                                                        <div class="am-u-sm-12 tanjie">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >B</span>统一社会信用代码</h3>
                                                            <label class="am-checkbox am-u-sm-6 " style="margin: 0">
                                                                <input class="am-fl" type="text" name="shxydm"  value="<?php echo ($user['Company']['shxydm']); ?>"  data-am-ucheck readonly>
                                                            </label>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >03</span> 法定代表人(单位负责人)</h3>
                                                            <label class="am-checkbox am-u-sm-6 " style="margin: 0">
                                                                <input class="am-fl" type="text" name="fddbr"  value="<?php echo ($user['Company']['fddbr']); ?>"  data-am-ucheck readonly>
                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >04 </span>  联系电话(含区号)</h3>
                                                            <label class="am-checkbox am-u-sm-6 " style="margin: 0">
                                                                <input class="am-fl" type="text"  name="dianhua"   value="<?php echo ($user['Company']['dianhua']); ?>" data-am-ucheck readonly>
                                                            </label>
                                                        </div>
                                                    </td>
                                                    <script>
                                                    function textput(obj) {
                                                        var oVal = obj.val();
                                                        var aVal = []
                                                        var eleText = obj.closest("td").find('input[type=text]')
                                                        var eleHide = obj.closest("td").find('input[type=hidden]')
                                                        for (var i = 0; i < eleText.length; i++) {
                                                            aVal.push(eleText[i].value)
                                                        }
                                                        var json = {}
                                                        for (var i = 0; i < aVal.length; i++) {
                                                            json[i] = aVal[i]
                                                        }
                                                        eleHide.val(JSON.stringify(json))
                                                    }
													
													
													function textput2(obj) {
                                                        var oVal = obj.val();
														
                                                        var aVal = []
                                                        var eleText = obj.closest("tbody").find('input[type=text]')
                                                        var eleHide = obj.closest("tbody").find('input[type=hidden]')
                                                        for (var i = 0; i < eleText.length; i++) {
                                                            aVal.push(eleText[i].value)
                                                        }
                                                        var json = {}
                                                        for (var i = 0; i < aVal.length; i++) {
                                                            json[i] = aVal[i]
                                                        }
                                                        eleHide.val(JSON.stringify(json))
                                                    }
													
													function validata(obj){
														$.ajax({
														//    cache: true,
															type: "POST",
															url:"<?php echo U('Home/CompanyRule/validata');?>",
															data:$('#qform').serialize(),// 你的formid
															async: false,
															error: function(request) {
																alert("Connection error");
															},
															success: function(data) {
															if(obj.value==9){data.status=2;}	
																	
															if(data.status == 0){
																subajax(obj);
															}else if(data.status==1){
															$("#myalert2").html(data.content);
																confirmt(obj,data);
																 shengheshow()
																
															}else if(data.status==2){
																$("#myalert2").html(data.content);
																confirmt2(obj,data);
															//	 shengheshow()
																 return false;
															}
															
														}
														});
													  }
													  confirmt = function(obj,data) {
	$("#myconfirm2").html("您的问卷中共有["+Number(data.statusInfo.cw+data.statusInfo.jg+data.statusInfo.ts)+"]条错误,强制性错误["+data.statusInfo.cw+"]条,核实性错误["+data.statusInfo.jg+"]条,可忽略性错误["+data.statusInfo.ts+"]条,确定要提交吗？");
      $('#my-confirm').modal({
        relatedTarget: this,
        onConfirm: function(options) {
          var $link = $(this.relatedTarget).prev('a');
          var msg = $link.length ? '你要删除的链接 ID 为 ' + $link.data('id') :
            '确定了，但不知道要整哪样';
			
			
			subajax(obj);
        //  alert(msg);
        },
        // closeOnConfirm: false,
        onCancel: function() {
      //    alert('算求，不弄了');
        }
      });
    }
	
	
	confirmt2 = function(obj,data) {
	$("#myconfirm2").html("您的问卷中共有["+Number(data.statusInfo.cw+data.statusInfo.jg+data.statusInfo.ts)+"]条错误,强制性错误["+data.statusInfo.cw+"]条,核实性错误["+data.statusInfo.jg+"]条,可忽略性错误["+data.statusInfo.ts+"]条");
      $('#my-confirm2').modal({
        relatedTarget: this,
        onConfirm: function(options) {
          var $link = $(this.relatedTarget).prev('a');
          var msg = $link.length ? '你要删除的链接 ID 为 ' + $link.data('id') :
            '确定了，但不知道要整哪样';
			
			
			//subajax(obj);
        //  alert(msg);
        },
        // closeOnConfirm: false,
      
      });
    }
                                                    </script>
                                                </tr>
                                                <tr>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3><span class="am-badge am-badge-primary" >05</span>单位所在地</h3>
                                                            <label class="am-checkbox  am-fl am-u-sm-9" style="margin: 0">
                                                                <input class="am-fl" type="text" onchange="textput($(this));" value="<?php echo ($user['Company']['dwszd'][0]); ?>"   data-am-ucheck readonly><span class="am-fl">省(自治区、直辖市)</span>
                                                                <input class="am-fl" type="text"  onchange="textput($(this));" value="<?php echo ($user['Company']['dwszd'][1]); ?>"  data-am-ucheck readonly><span class="am-fl">地(区、市、州、盟)</span>
                                                                <input class="am-fl" type="text"  onchange="textput($(this));" value="<?php echo ($user['Company']['dwszd'][2]); ?>"  data-am-ucheck readonly><span class="am-fl">县(区、市、旗)</span>
                                                                <input class="am-fl" type="text"  onchange="textput($(this));" value="<?php echo ($user['Company']['dwszd'][3]); ?>"  data-am-ucheck readonly><span class="am-fl">乡(镇)</span>
                                                                <input class="am-fl" type="text"  onchange="textput($(this));" value="<?php echo ($user['Company']['dwszd'][4]); ?>"  data-am-ucheck readonly><span class="am-fl">街(村)</span>
                                                                <input class="am-fl" type="text"  onchange="textput($(this));" value="<?php echo ($user['Company']['dwszd'][5]); ?>"  data-am-ucheck readonly><span class="am-fl">门牌号</span>
																<input type="hidden" name="dwszd" value='<?php echo (json_encode($user['Company']['dwszd'],JSON_FORCE_OBJECT)); ?>' readonly/>
															</label>
                                                        </div>
                                                    </td>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >06</span> 区划代码</h3>
                                                            <label class="am-checkbox am-u-sm-6 " style="margin: 0">
																<input type="text" name="qydm" value="<?php echo ($user['Company']['qydm']); ?>" readonly/>
                                                              
                                                            </label>
                                                        </div>
                                                        <div class="am-u-sm-12 tanjie">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >07</span> 邮政编码</h3>
                                                            <label class="am-checkbox am-u-sm-6 " style="margin: 0">
                                                                <input class="am-fl" type="text"  name="yzbm"  value="<?php echo ($user['Company']['yzbm']); ?>"  data-am-ucheck readonly>
                                                            </label>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >08</span> 是否有出口业务</h3>
                                                            <label class="am-radio am-u-sm-3 " style="margin: 0">
                                                                <input type="radio"  name="sfck" value="1"  value="" data-am-ucheck <?php if($user['Company']['sfck']==1): ?>checked<?php endif; ?> disabled> 是
                                                            </label>
                                                            <label class="am-radio am-u-sm-3 am-fl" style="margin: 0">
                                                                <input type="radio"  name="sfck" value="2"  value="" data-am-ucheck  <?php if($user['Company']['sfck']==2): ?>checked<?php endif; ?> disabled>否
                                                            </label>
															<input type="hidden" name="sfck" value="<?php echo ($user['Company']['sfck']); ?>" />
                                                        </div>
                                                    </td>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >09 </span> 是否为上市公司</h3>
                                                            <label class="am-radio am-u-sm-3 " style="margin: 0">
                                                                <input type="radio"  name="sfss" value="1" value="" data-am-ucheck <?php if($user['Company']['sfss']==1): ?>checked<?php endif; ?> disabled> 是
                                                            </label>
                                                            <label class="am-radio am-u-sm-3 am-fl " style="margin: 0">
                                                                <input type="radio"  name="sfss" value="2" value="" data-am-ucheck  <?php if($user['Company']['sfss']==2): ?>checked<?php endif; ?> disabled> 否
                                                            </label>
															<input type="hidden" name="sfss" value="<?php echo ($user['Company']['sfss']); ?>" />
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <div class="am-u-sm-12">
                                                            <h3><span class="am-badge am-badge-primary">10</span>    登记注册类型</h3>
															
															<div class="am-clear-fix">
															<!--1-->
															<div class="am-fl am-u-sm-3 am-u-lg-3 am-u-md-3" >
															 <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="110" data-am-ucheck <?php if($user[Company][djzclx]=='110'): ?>checked<?php endif; ?> disabled> 110国有
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="120" data-am-ucheck  <?php if($user[Company][djzclx]=='120'): ?>checked<?php endif; ?> disabled> 120集体
                                                            </label>
                                                           
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="130" data-am-ucheck <?php if($user[Company][djzclx]=='130'): ?>checked<?php endif; ?>  disabled> 130股份合作
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="141" data-am-ucheck <?php if($user[Company][djzclx]=='141'): ?>checked<?php endif; ?> disabled> 141国有联营
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="142" data-am-ucheck <?php if($user[Company][djzclx]=='142'): ?>checked<?php endif; ?> disabled> 142集体联营
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="143" data-am-ucheck <?php if($user[Company][djzclx]=='143'): ?>checked<?php endif; ?> disabled> 143国有与集体联营
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="149" data-am-ucheck <?php if($user[Company][djzclx]=='149'): ?>checked<?php endif; ?> disabled> 149其他联营
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="151" data-am-ucheck <?php if($user[Company][djzclx]=='151'): ?>checked<?php endif; ?> disabled> 151国有独资公司
                                                            </label>
                                                            
															</div>
															<!--2-->
															<div class="am-fl am-u-sm-3 am-u-lg-3 am-u-md-3" >
															 <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="159" data-am-ucheck <?php if($user[Company][djzclx]=='159'): ?>checked<?php endif; ?>  disabled> 159其他有限责任公司
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="160" data-am-ucheck <?php if($user[Company][djzclx]=='160'): ?>checked<?php endif; ?> disabled> 160股份有限公司
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="171" data-am-ucheck <?php if($user[Company][djzclx]=='171'): ?>checked<?php endif; ?> disabled> 171私营独资
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="172" data-am-ucheck <?php if($user[Company][djzclx]=='172'): ?>checked<?php endif; ?> disabled> 172私营合伙
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="173" data-am-ucheck <?php if($user[Company][djzclx]=='173'): ?>checked<?php endif; ?> disabled> 173私营有限责任公司
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="174" data-am-ucheck <?php if($user[Company][djzclx]=='174'): ?>checked<?php endif; ?> disabled> 174私营股份有限公司
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="190" data-am-ucheck <?php if($user[Company][djzclx]=='190'): ?>checked<?php endif; ?> disabled> 190其他
                                                            </label>
															
															</div>
															<!--3-->
															<div class="am-fl am-u-sm-3 am-u-lg-3 am-u-md-3" >
															<label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="210" data-am-ucheck <?php if($user[Company][djzclx]=='210'): ?>checked<?php endif; ?> disabled> 210与港澳台商合资经营
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="220" data-am-ucheck <?php if($user[Company][djzclx]=='220'): ?>checked<?php endif; ?> disabled> 220与港澳台商合作经营
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="230" data-am-ucheck <?php if($user[Company][djzclx]=='230'): ?>checked<?php endif; ?> disabled> 230港澳台独资
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="240" data-am-ucheck <?php if($user[Company][djzclx]=='240'): ?>checked<?php endif; ?> disabled> 240港澳台商投资股份有限公司
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="290" data-am-ucheck <?php if($user[Company][djzclx]=='290'): ?>checked<?php endif; ?> disabled> 290其他港澳台投资
                                                            </label>
															
															</div>
															<!--4-->
															<div class="am-fl am-u-sm-3 am-u-lg-3 am-u-md-3" >
															<label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="310" data-am-ucheck <?php if($user[Company][djzclx]=='310'): ?>checked<?php endif; ?> disabled> 310中外合资经营
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="320" data-am-ucheck <?php if($user[Company][djzclx]=='320'): ?>checked<?php endif; ?> disabled> 320中外合作经营
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="330" data-am-ucheck <?php if($user[Company][djzclx]=='330'): ?>checked<?php endif; ?> disabled> 330外资企业
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="340" data-am-ucheck <?php if($user[Company][djzclx]=='340'): ?>checked<?php endif; ?> disabled> 340外商投资股份有限公司
                                                            </label>
                                                            <label class="am-radio" style="margin: 0">
                                                                <input type="radio"  name="djzclx" value="390" data-am-ucheck <?php if($user[Company][djzclx]=='390'): ?>checked<?php endif; ?>  disabled> 390其他外商投资
                                                            </label>
															
															</div>
															
															</div>
                                                            
                                                            <input type="hidden" name="djzclx" value="<?php echo ($user[Company][djzclx]); ?>" />
                                                           
                                                           
                                                           
                                                          
                                                           
                                                           
                                                           
                                                           
                                                          
                                                           
                                                           
                                                           
                                                           
                                                           
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-fl"><span class="am-badge am-badge-primary" >11</span> 是否为国有控股企业</h3>
                                                            <label class="am-radio am-u-sm-3 " style="margin: 0">
                                                                <input type="radio"  name="sfgykg" value="1"  value="" data-am-ucheck <?php if($user['Company']['sfgykg']==1): ?>checked<?php endif; ?> disabled> 是
                                                            </label>
                                                            <label class="am-radio am-u-sm-3 am-fl" style="margin: 0">
                                                                <input type="radio"  name="sfgykg" value="2"  value="" data-am-ucheck  <?php if($user['Company']['sfgykg']==2): ?>checked<?php endif; ?> disabled>否
                                                            </label>
															<input type="hidden" name="sfgykg" value="<?php echo ($user[Company][sfgykg]); ?>"/>
                                                        </div>
                                                    </td>
                                                    <td class="am-u-sm-6">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-fl am-u-sm-4"><span class="am-badge am-badge-primary" >12 </span> 单位规模</h3>
                                                            <label class="am-radio am-u-sm-2 " style="margin: 0">
                                                                <input type="radio"  name="dwgm" value="1"  data-am-ucheck <?php if($user['Company']['dwgm']==1): ?>checked<?php endif; ?> disabled> 大型
                                                            </label>
                                                            <label class="am-radio am-u-sm-2 am-fl " style="margin: 0">
                                                                <input type="radio"  name="dwgm" value="2"  data-am-ucheck  <?php if($user['Company']['dwgm']==2): ?>checked<?php endif; ?> disabled> 中型
                                                            </label>
                                                            <label class="am-radio am-u-sm-2 am-fl " style="margin: 0">
                                                                <input type="radio"  name="dwgm" value="3"  data-am-ucheck  <?php if($user['Company']['dwgm']==3): ?>checked<?php endif; ?> disabled> 小型
                                                            </label>
                                                            <label class="am-radio am-u-sm-2 am-fl " style="margin: 0">
                                                                <input type="radio"  name="dwgm" value="4"  data-am-ucheck  <?php if($user['Company']['dwgm']==4): ?>checked<?php endif; ?> disabled> 微型
                                                            </label>
															<input type="hidden" name="dwgm" value="<?php echo ($user[Company][dwgm]); ?>"/>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                   <td colspan="2">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-u-sm-4 am-fl"><span class="am-badge am-badge-primary">13</span>        行业代码（统计机构填写）</h3>
                                                            <label class="am-radio am-u-sm-8 am-fl" style="margin: 0">
                                                                <input type="text" id="hydm"   name="hydm" value="<?php echo ($user['Company']['hydm']); ?>" data-am-ucheck readonly="true">
																
                                                            </label>
															
															
															
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-u-sm-3 am-fl"><span class="am-badge am-badge-primary">14</span>            从业人员期末人数</h3>
                                                            <label class="am-radio am-u-sm-9 am-fl" style="margin: 0">
                                                                <input type="text"  name="qmcyrs"   value="<?php echo ($user['Company']['qmcyrs']); ?>"  data-am-ucheck>人
                                                            </label>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-u-sm-12 am-fl"><span class="am-badge am-badge-primary">15</span>            主要经济指标（不保留小数位）</h3>
                                                            <label class="am-radio am-u-sm-4 am-fl" style="margin: 0">
                                                                营业收入
                                                                <input type="text" value="<?php echo ($user['Company']['zyjjzb'][0]); ?>"   onchange="textput($(this));"  data-am-ucheck  readonly="true">千元
                                                            </label>
                                                            <label class="am-radio am-u-sm-4 am-fl" style="margin: 0">
                                                                其中：主营业务收入
                                                                <input type="text" value="<?php echo ($user['Company']['zyjjzb'][1]); ?>"   onchange="textput($(this));" data-am-ucheck  readonly>千元
                                                            </label>
                                                            <label class="am-radio am-u-sm-4 am-fl" style="margin: 0">
                                                                资产总计
                                                                <input type="text"    value="<?php echo ($user['Company']['zyjjzb'][2]); ?>"   onchange="textput($(this));"  data-am-ucheck  readonly>千元
                                                            </label>
															<input type="hidden" name="zyjjzb" value='<?php echo (json_encode($user["Company"]["zyjjzb"],JSON_FORCE_OBJECT)); ?>' readonly/>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2">
                                                        <div class="am-u-sm-12">
                                                            <h3 class="am-u-sm-12 am-fl"><span class="am-badge am-badge-primary">16</span>               主要业务活动(填写营业收入份额最大的三项业务活动或主要产品，营业收入所占份额不保留小数)</h3>
                                                            <table class="am-table am-table-bordered am-table-striped am-table-compact">
                                                                <thead>
                                                                    <tr>
                                                                        <th>业务活动(或主要产品)名称</th>
                                                                        <th>行业代码</th>
                                                                        <th>营业收入所占份额约为(%)</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                     <tr  >
                                                            <td>
                                                                <input type="text"  value="<?php echo ($user['Company']['zyywhd'][0]); ?>"   onchange="textput2($(this));" readonly/>
                                                            </td>
                                                            <td>
                                                                <input type="text" value="<?php echo ($user['Company']['zyywhd'][1]); ?>"  onchange="textput2($(this));" readonly/>
                                                            </td>
                                                            <td>
                                                                <input type="text" value="<?php echo ($user['Company']['zyywhd'][2]); ?>"  onchange="textput2($(this));" readonly/>
                                                            </td>
															
                                                        </tr>
                                                        <tr  >
                                                            <td>
                                                                <input type="text" value="<?php echo ($user['Company']['zyywhd'][3]); ?>"  onchange="textput2($(this));" readonly/>
                                                            </td>
                                                            <td>
                                                                <input type="text" value="<?php echo ($user['Company']['zyywhd'][4]); ?>"  onchange="textput2($(this));" readonly/>
                                                            </td>
                                                            <td>
                                                                <input type="text" value="<?php echo ($user['Company']['zyywhd'][5]); ?>"  onchange="textput2($(this));" readonly/>
                                                            </td>
															
                                                        </tr>
                                                        <tr  >
                                                            <td>
                                                                <input type="text" value="<?php echo ($user['Company']['zyywhd'][6]); ?>"  onchange="textput2($(this));" readonly/>
                                                            </td>
                                                            <td>
                                                                <input type="text" value="<?php echo ($user['Company']['zyywhd'][7]); ?>"  onchange="textput2($(this));"  readonly/>
                                                            </td>
                                                            <td>
                                                                <input type="text" value="<?php echo ($user['Company']['zyywhd'][8]); ?>"  onchange="textput2($(this));"  readonly/>
																
                                                            </td>
															
                                                        </tr>
														<input type="hidden" name="zyywhd" value='<?php echo (json_encode($user['Company']['zyywhd'],JSON_FORCE_OBJECT)); ?>'  readonly/>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </td>
                                                </tr>
												<tr>
                                                    <td colspan="2">
                                                        <div class="am-u-sm-12">
                                                            
                                                            <label class="am-radio  am-fl" style="margin: 0">
                                                                联系人姓名：
                                                                <input type="text" value="<?php echo ($user['Company']['lxrxm']); ?>"  name="lxrxm"  onchange="textput($(this));"  data-am-ucheck>
                                                            </label>
                                                            <label class="am-radio  am-fl" style="margin: 0">
                                                                职务：
                                                                <input type="text" value="<?php echo ($user['Company']['zw']); ?>"  name="zw"   onchange="textput($(this));" data-am-ucheck>
                                                            </label>
                                                            <label class="am-radio  am-fl" style="margin: 0">
                                                                电话：
                                                                <input type="text"   name="lxdianhua"    value="<?php echo ($user['Company']['lxdianhua']); ?>"   onchange="textput($(this));"  data-am-ucheck>
                                                            </label>
															<label class="am-radio  am-fl" style="margin: 0">
                                                                报出日期：
                                                                <input type="text"    value="<?php echo ($user['Company']['updatetime']); ?>"   onchange="textput($(this));"  data-am-ucheck>
                                                            </label>
															
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
											
                                        </table>
                                    </div>
									
									<?php if($user['Company']['status'] != 2): ?><button  class="am-btn am-btn-reset" onclick="javascript:history.go(-1);" >返回</button><?php endif; ?>
                                </div>
								
                                <!-- <2016/6/15修改>e -->
                            </div>
                        </div>
						</form>
									
									
									
                                </div>
                            </div>
	
							
                        </div>
	  
	  </div>
    </div>
	</div>
    <footer class="admin-content-footer">
      <hr>
   
    </footer>

  </div>
  
  
  <style>
    .admin-main{
        padding-bottom: 51px
    }
</style> 
<div class="am-modal am-modal-alert" tabindex="-1" id="my-alert">
  <div class="am-modal-dialog"  style="border:4px solid #333">
    <div class="am-modal-hd">信息提示</div>
    <div class="am-modal-bd" id="myalert">
      验证通过
    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn">确定</span>
    </div>
  </div>
</div>
  	<!-- as -->
<header class="am-topbar am-topbar-inverse admin-header" style="bottom: 0;top:auto;margin-top:0;background: #eee;color: #333;overflow:hidden;padding-bottom=15px" id="shengchafoot">
        <button type="button" class="am-btn am-btn-secondary" style="margin-left: 300px" id="shengcha">审核信息&nbsp;<span style='font-size:20px'>↑</span></button>

        <div class="shengchatab" style="overflow-y:auto ;display:none;padding-left=300px;position:absolute:bottom:50px" id="myalert2" >
            (请先审核！！！)
        </div>
		</form>
        <script>
        var onoff=true;
            $("#shengcha").click(function(event) {
                if(onoff){
                    shengheshow();
					$(this).html("审核信息&nbsp;<span style='font-size:20px'>↓</span>")
                }else{
                     $(".admin-main").css('paddingBottom', '51px');
					$("#shengchafoot").css('height', '51px');
					$(".shengchatab").hide();
					$(this).html("审核信息&nbsp;<span style='font-size:20px'>↑</span>")
					onoff=!onoff; 
                }
               
            });
			
			function shengheshow(){
			  $(".admin-main").css('paddingBottom', '300px');
					$("#shengchafoot").css('height', '300px').css("paddingBottom",'15px');
					$(".shengchatab").show().css("height","250px").css("paddingBottom",'155px').css("paddingLeft",'300px').css({
					"position":"absolute",
					"bottom":"10px",
					"width":"100%"
				});
                 onoff=false;
			
			}
        </script>
    </header>
<!-- ae -->
  <script>
  		 
		 document.onreadystatechange = function () {   
                 if(document.readyState=="complete") {          
                     var obj = new Object;
					obj.value = 9;
					
					validata(obj);
                  }   
              }   

</script>
  <!-- content end -->

<a href="#" class="am-icon-btn am-icon-th-list am-show-sm-only admin-menu" data-am-offcanvas="{target: '#admin-offcanvas'}"></a>

<footer>
  <hr>

</footer>

<!--[if lt IE 9]>
<script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="/Public/assets/js/amazeui.ie8polyfill.min.js"></script>
<![endif]-->


<script src="/Public/assets/js/amazeui.min.js"></script>
<script src="/Public/assets/js/app.js"></script>
</body>
</html>