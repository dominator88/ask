<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html class="no-js">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>问卷调查</title>
  <meta name="description" content="这是一个 table 页面">
  <meta name="keywords" content="table">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="renderer" content="webkit">
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <link rel="icon" type="image/png" href="/Public/assets/i/favicon.png">
  <link rel="apple-touch-icon-precomposed" href="/Public/assets/i/app-icon72x72@2x.png">
  <meta name="apple-mobile-web-app-title" content="Amaze UI" />
  <link rel="stylesheet" href="/Public/assets/css/amazeui.min.css"/>
  <link rel="stylesheet" href="/Public/assets/css/admin.css">
	<!--[if (gte IE 9)|!(IE)]><!-->
	<script src="/Public/assets/js/jquery.min.js"></script>
	<!--<![endif]-->
</head>
<body>
<!--[if lte IE 9]>
<p class="browsehappy">你正在使用<strong>过时</strong>的浏览器，Amaze UI 暂不支持。 请 <a href="http://browsehappy.com/" target="_blank">升级浏览器</a>
  以获得更好的体验！</p>
<![endif]-->

<header class="am-topbar am-topbar-inverse admin-header">
  <div class="am-topbar-brand">
    <strong>国家统计局武汉调查队统计平台</strong> 
  </div>

  <button class="am-topbar-btn am-topbar-toggle am-btn am-btn-sm am-btn-success am-show-sm-only" data-am-collapse="{target: '#topbar-collapse'}"><span class="am-sr-only">导航切换</span> <span class="am-icon-bars"></span></button>

  <div class="am-collapse am-topbar-collapse" id="topbar-collapse">

    <ul class="am-nav am-nav-pills am-topbar-nav am-topbar-right admin-header-list">
      
      <li class="am-dropdown" data-am-dropdown>
        <a class="am-dropdown-toggle" data-am-dropdown-toggle href="javascript:;">
          <span class="am-icon-users"></span> <?php echo (session('USERNAME')); ?> <span class="am-icon-caret-down"></span>
        </a>
        <ul class="am-dropdown-content">
          <li><a href="<?php echo U('Home/Index/userCenter');?>"><span class="am-icon-user"></span> 资料</a></li>
          <!--li><a href="#"><span class="am-icon-cog"></span> 设置</a></li-->
          <li><a href="<?php echo U('Home/Index/logout');?>"><span class="am-icon-power-off"></span> 退出</a></li>
        </ul>
      </li>
      <li class="am-hide-sm-only"><a href="javascript:;" id="admin-fullscreen"><span class="am-icon-arrows-alt"></span> <span class="admin-fullText">开启全屏</span></a></li>
    </ul>
  </div>
</header>

<div class="am-cf admin-main">
  <!-- sidebar start -->
  <div class="admin-sidebar am-offcanvas" id="admin-offcanvas">
    <div class="am-offcanvas-bar admin-offcanvas-bar">
      <ul class="am-list admin-sidebar-list">
        <li><a href="<?php echo U('Home/Index/userCenter');?>"><span class="am-icon-home"></span> 个人中心</a></li>
		  <li><a href="<?php echo U('Home/Index/listAnnouncement');?>"><span class="am-icon-file"></span> 公告管理</a></li>
        <li class="admin-parent">
          <a class="am-cf" data-am-collapse="{target: '#collapse-nav'}"><span class="am-icon-file"></span> 我的问卷 <span class="am-icon-angle-right am-fr am-margin-right"></span></a>
          <ul class="am-list am-collapse admin-sidebar-sub am-in" id="collapse-nav">
            <li><a href="<?php echo U('/Home/Index/newQuestionnaires');?>" class="am-cf"><span class="am-icon-check"></span> 填报问卷<span class="am-icon-star am-fr am-margin-right admin-icon-yellow"></span></a></li>
            <li><a href="<?php echo U('Home/Index/historyQuestionnaires');?>"><span class="am-icon-puzzle-piece"></span> 历史问卷</a></li>
          </ul>
        </li>
         <li><a href="<?php echo U('Home/Index/help');?>"><span class="am-icon-file"></span> 帮助中心</a></li>
        <li><a href="<?php echo U('Home/Index/logout');?>"><span class="am-icon-sign-out"></span> 注销</a></li>
      </ul>

      <!--div class="am-panel am-panel-default admin-sidebar-panel">
        <div class="am-panel-bd">
          <p><span class="am-icon-bookmark"></span> 公告</p>
          <p>时光静好，与君语；细水流年，与君同。—— xx</p>
        </div>
      </div-->

     
    </div>
  </div>
  <!-- sidebar end -->

   <div class="admin-content">
            <div class="admin-content-body">
 <div class="am-center" style="width: 900px">

<br/>
 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 
国家统计局武汉调查队工业处<br>
地址：武汉市沿江大道190号　邮编：430017　<br>
联系电话：82846669，82817616<br>
传真：82848216<br>
采购经理调查QQ群：218785203<br>
技术支持 武汉火凤凰云计算服务股份有限公司<br>
<hr>
<a href="/Public/2016采购经理调查统计报表制度.doc">2016采购经理调查统计报表制度（附件下载）</a>
</div>
</div>
</div>


<a href="#" class="am-icon-btn am-icon-th-list am-show-sm-only admin-menu" data-am-offcanvas="{target: '#admin-offcanvas'}"></a>

<footer>
  <hr>

</footer>

<!--[if lt IE 9]>
<script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
<script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="/Public/assets/js/amazeui.ie8polyfill.min.js"></script>
<![endif]-->


<script src="/Public/assets/js/amazeui.min.js"></script>
<script src="/Public/assets/js/app.js"></script>
</body>
</html>