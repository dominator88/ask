<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="UTF-8">
		<title>Document</title>
		<link rel="stylesheet" href="/Public/assets/css/amazeui.min.css">
		<link rel="stylesheet" href="/Public/assets/css/login.css">
		<script type="text/javascript" src="/Public/assets/js/jquery.min.js">
		</script>
		<style>
			body {
				text-align: center;
				padding-top: 5px;
			}
			
			#bower img {
				border: none;
			}
			
			#bower h2,
			#bower h3,
			#bower h4 {
				color: #fff;
				font-family: arial;
				padding: 0;
				margin: 0;
			}
			
			#bower strong {
				border-bottom: 1px dotted #930;
				font-weight: normal;
				padding-bottom: 2px;
				color: #fff;
			}
			
			#bower p {
				padding: 5px 0;
				letter-spacing: 20px;
			}
			
			#bower h4 {
				font-weight: normal;
			}
		</style>
	</head>

	<body>
		<noscript unselectable="on" id="noscript">
	<div class="aw-404 aw-404-wrap container">
		<img src="http://ask.amazeui.org/static/common/no-js.jpg">
		<p>你的浏览器禁用了JavaScript, 请开启后刷新浏览器获得更好的体验!</p>
	</div>
</noscript>

		<div id="wrapper">
			<div class="aw-login-box">
				<div class="mod-body am-cf">
					<div class="content am-fl">
						<h1 class="logo" style="float: left;width: 50px;margin: 0;margin-bottom: 20px;"></h1>
						<h2 style="float: right;line-height: 41px;margin: 0;margin-bottom: 20px;">国家统计局武汉调查队统计平台
</h2>
						<form method="post" class="am-form">
							<input type="hidden" name="return_url" value="" />
							<ul >
								<li >
									<input type="text" id="aw-login-user-name" class="am-form-field am-radius" placeholder=" 组织机构代码" name="userName" />
								</li>
								<li>
									<input type="password" id="aw-login-user-password" class="am-form-field am-radius" placeholder="密码" name="password" />
								</li>
								<li class="last">
									 <input type="submit" name="" value="登 录" class="am-btn am-btn-primary am-btn-sm am-fr">
									<label>
								<input type="checkbox" value="1" name="net_auto_login" />
								记住我							</label>
									
								</li>
							</ul>
						</form>
					</div>
					<div class="side-bar am-fl">
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript" src=""></script>
		<div class="aw-footer-wrap">
			<div class="aw-footer;" style="font-size:14px;color:#fff">  地址：武汉市沿江大道190号　 邮编：430017 　版权所有：国家统计局武汉调查队 
			</span>
				<span class="am-hide-sm-only">
</span>
		</div>
			<div id="bower">
				
				<h3>建议使用 <strong>Chrome</strong>、<strong>Safari</strong> 浏览器访问</h3>
				<p>
					<a href="http://sw.bos.baidu.com/sw-search-sp/software/fc14f1545b7/ChromeStandalone_51.0.2704.106_Setup.exe" target="_blank"><img src="/Public/assets/i/chrome.png" alt="chrome" style="width: 50px;" /></a>

					<a href="http://www.firefox.com/" target="_blank"><img src="/Public/assets/i/firefox.png" alt="safari" style="width: 50px;" /></a>

				</p>

			</div>
		</div>

	</body>

</html>