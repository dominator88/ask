<?php if (!defined('THINK_PATH')) exit();?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta http-equiv=Content-Type  content="text/html; charset=utf-8" ><meta name=ProgId  content=Word.Document ><meta name=Generator  content="Microsoft Word 14" ><meta name=Originator  content="Microsoft Word 14" ><title></title><!--[if gte mso 9]><xml><w:WordDocument><w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel><w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery><w:DisplayVerticalDrawingGridEvery>2</w:DisplayVerticalDrawingGridEvery><w:DocumentKind>DocumentNotSpecified</w:DocumentKind><w:DrawingGridVerticalSpacing>7.8 磅</w:DrawingGridVerticalSpacing><w:PunctuationKerning></w:PunctuationKerning><w:View>Web</w:View><w:Compatibility><w:DontGrowAutofit/><w:BalanceSingleByteDoubleByteWidth/><w:DoNotExpandShiftReturn/><w:UseFELayout/></w:Compatibility><w:Zoom>0</w:Zoom></w:WordDocument></xml><![endif]--><!--[if gte mso 9]><xml><w:LatentStyles DefLockedState="false"  DefUnhideWhenUsed="true"  DefSemiHidden="true"  DefQFormat="false"  DefPriority="99"  LatentStyleCount="260" >
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Normal" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 9" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 9" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 9" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Normal Indent" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="footnote text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="annotation text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="header" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="footer" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index heading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="caption" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="table of figures" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="envelope address" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="envelope return" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="footnote reference" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="annotation reference" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="line number" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="page number" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="endnote reference" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="endnote text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="table of authorities" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="macro" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="toa heading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Title" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Closing" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Signature" ></w:LsdException>
<w:LsdException Locked="false"  Priority="1"  SemiHidden="false"  Name="Default Paragraph Font" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text Indent" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Message Header" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Subtitle" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Salutation" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Date" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text First Indent" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text First Indent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Note Heading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text Indent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text Indent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Block Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Hyperlink" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="FollowedHyperlink" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Strong" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Emphasis" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Document Map" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Plain Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="E-mail Signature" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Normal (Web)" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Acronym" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Address" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Cite" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Code" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Definition" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Keyboard" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Preformatted" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Sample" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Typewriter" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Variable" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  QFormat="true"  Name="Normal Table" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="annotation subject" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="No List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Simple 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Simple 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Simple 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Classic 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Classic 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Classic 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Classic 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Colorful 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Colorful 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Colorful 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table 3D effects 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table 3D effects 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table 3D effects 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Contemporary" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Elegant" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Professional" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Subtle 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Subtle 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Web 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Web 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Web 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Balloon Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="59"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Theme" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 6" ></w:LsdException>
</w:LatentStyles></xml><![endif]--><style>
@font-face{
font-family:"Times New Roman";
}

@font-face{
font-family:"宋体";
}

@font-face{
font-family:"Calibri";
}

@font-face{
font-family:"Wingdings";
}

@font-face{
font-family:"Cambria";
}

@font-face{
font-family:"黑体";
}

p.MsoNormal{
mso-style-name:正文;
mso-style-parent:"";
margin:0pt;
margin-bottom:.0001pt;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
line-height:150%;
font-family:Calibri;
font-size:14.0000pt;
}

h1{
mso-style-name:"标题 1";
mso-style-next:正文;
margin-top:20.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
mso-outline-level:1;
font-family:Cambria;
color:rgb(15,36,62);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:16.0000pt;
}

h2{
mso-style-name:"标题 2";
mso-style-next:正文;
margin-top:6.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
mso-outline-level:2;
font-family:Cambria;
color:rgb(23,54,93);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:14.0000pt;
}

h3{
mso-style-name:"标题 3";
mso-style-next:正文;
margin-top:6.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
mso-outline-level:3;
font-family:Cambria;
color:rgb(31,73,125);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:12.0000pt;
}

h4{
mso-style-name:"标题 4";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:5.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
border-bottom:1.0000pt solid rgb(113,160,220);
mso-border-bottom-alt:0.5000pt solid rgb(113,160,220);
padding:0pt 0pt 1pt 0pt ;
mso-outline-level:4;
font-family:Cambria;
color:rgb(48,113,195);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:10.0000pt;
}

h5{
mso-style-name:"标题 5";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:5.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
border-bottom:1.0000pt solid rgb(84,141,212);
mso-border-bottom-alt:0.5000pt solid rgb(84,141,212);
padding:0pt 0pt 1pt 0pt ;
mso-outline-level:5;
font-family:Cambria;
color:rgb(48,113,195);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:10.0000pt;
}

h6{
mso-style-name:"标题 6";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:5.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
border-bottom:1.0000pt dotted rgb(147,137,83);
mso-border-bottom-alt:1.0000pt dotted rgb(147,137,83);
padding:0pt 0pt 1pt 0pt ;
mso-outline-level:6;
line-height:150%;
font-family:Cambria;
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:10.0000pt;
}

p.MsoHeading7{
mso-style-name:"标题 7";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:5.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
border-bottom:1.0000pt dotted rgb(147,137,83);
mso-border-bottom-alt:1.0000pt dotted rgb(147,137,83);
padding:0pt 0pt 1pt 0pt ;
mso-outline-level:7;
font-family:Cambria;
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:8.0000pt;
}

p.MsoHeading8{
mso-style-name:"标题 8";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
mso-outline-level:8;
font-family:Cambria;
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:8.0000pt;
}

p.Msoheading9{
mso-style-name:"标题 9";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
mso-outline-level:9;
font-family:Cambria;
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:8.0000pt;
}

span.10{
font-family:Calibri;
}

span.15{
font-family:Calibri;
mso-bidi-font-family:'Times New Roman';
letter-spacing:0.0000pt;
font-weight:bold;
}

span.16{
font-family:Calibri;
mso-bidi-font-family:'Times New Roman';
color:rgb(90,90,90);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
}

span.17{
font-family:Calibri;
font-size:9.0000pt;
}

span.18{
font-family:Calibri;
mso-bidi-font-family:'Times New Roman';
color:rgb(90,90,90);
font-style:italic;
font-size:10.0000pt;
}

span.19{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(23,54,93);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:14.0000pt;
}

span.20{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:8.0000pt;
}

span.21{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(48,113,195);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
}

span.22{
font-family:Cambria;
mso-fareast-font-family:宋体;
color:rgb(90,90,90);
letter-spacing:1.0000pt;
font-style:italic;
font-variant:small-caps;
}

span.23{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(23,54,93);
letter-spacing:0.2500pt;
font-variant:small-caps;
font-size:36.0000pt;
}

span.24{
font-family:Calibri;
font-size:9.0000pt;
}

span.25{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-variant:small-caps;
}

span.26{
font-family:Cambria;
mso-fareast-font-family:宋体;
color:rgb(23,54,93);
letter-spacing:0.5000pt;
font-weight:bold;
text-decoration:underline;
text-underline:single;
font-variant:small-caps;
}

span.27{
font-family:Calibri;
color:rgb(79,129,189);
letter-spacing:2.0000pt;
font-weight:bold;
font-variant:small-caps;
}

span.28{
font-family:Calibri;
mso-bidi-font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:0.2500pt;
font-variant:small-caps;
font-size:14.0000pt;
}

span.29{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:8.0000pt;
}

span.30{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(54,95,145);
font-variant:small-caps;
font-size:10.0000pt;
}

span.31{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(48,113,195);
letter-spacing:1.0000pt;
font-variant:small-caps;
}

span.32{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(31,73,125);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:12.0000pt;
}

span.33{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(15,36,62);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:16.0000pt;
}

span.34{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:8.0000pt;
}

span.35{
font-family:Cambria;
mso-fareast-font-family:宋体;
color:rgb(23,54,93);
letter-spacing:1.0000pt;
font-weight:bold;
font-style:italic;
font-variant:small-caps;
}

span.36{
font-family:Calibri;
color:rgb(90,90,90);
font-variant:small-caps;
}

p.MsoSubtitle{
mso-style-name:副标题;
mso-style-next:正文;
margin-bottom:30.0000pt;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
font-family:Calibri;
color:rgb(147,137,83);
letter-spacing:0.2500pt;
font-variant:small-caps;
font-size:14.0000pt;
}

p.MsoHeader{
mso-style-name:页眉;
mso-style-noshow:yes;
margin:0pt;
margin-bottom:.0001pt;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
border-bottom:1.0000pt solid windowtext;
mso-border-bottom-alt:0.7500pt solid windowtext;
padding:0pt 0pt 1pt 0pt ;
layout-grid-mode:char;
text-align:center;
font-family:Calibri;
font-size:9.0000pt;
}

p.MsoCaption{
mso-style-name:题注;
mso-style-next:正文;
margin:0pt;
margin-bottom:.0001pt;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
line-height:150%;
font-family:Calibri;
color:rgb(31,73,125);
letter-spacing:0.5000pt;
font-weight:bold;
font-variant:small-caps;
font-size:9.0000pt;
}

p.MsoTitle{
mso-style-name:标题;
mso-style-next:正文;
margin:0pt;
margin-bottom:.0001pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
font-family:Cambria;
color:rgb(23,54,93);
letter-spacing:0.2500pt;
font-variant:small-caps;
font-size:36.0000pt;
}

p.MsoFooter{
mso-style-name:页脚;
mso-style-noshow:yes;
margin:0pt;
margin-bottom:.0001pt;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
layout-grid-mode:char;
font-family:Calibri;
font-size:9.0000pt;
}

p.NewStyle42{
mso-style-name:无间隔;
margin:0pt;
margin-bottom:.0001pt;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
font-family:Calibri;
font-size:14.0000pt;
}

p.NewStyle43{
mso-style-name:列出段落;
margin-left:36.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
line-height:150%;
font-family:Calibri;
font-size:14.0000pt;
}

p.NewStyle44{
mso-style-name:引用;
mso-style-next:正文;
margin:0pt;
margin-bottom:.0001pt;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
line-height:150%;
font-family:Calibri;
color:rgb(90,90,90);
font-style:italic;
font-size:10.0000pt;
}

p.NewStyle45{
mso-style-name:明显引用;
mso-style-next:正文;
margin-right:21.6000pt;
margin-left:125.3000pt;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
border-top:1.0000pt solid rgb(123,160,205);
mso-border-top-alt:0.5000pt solid rgb(123,160,205);
border-right:1.5000pt solid rgb(54,95,145);
mso-border-right-alt:1.5000pt solid rgb(54,95,145);
border-bottom:1.5000pt solid rgb(54,95,145);
mso-border-bottom-alt:1.5000pt solid rgb(54,95,145);
border-left:1.0000pt solid rgb(123,160,205);
mso-border-left-alt:0.5000pt solid rgb(123,160,205);
padding:12pt 15pt 10pt 15pt ;
line-height:125%;
font-family:Cambria;
color:rgb(54,95,145);
font-variant:small-caps;
font-size:10.0000pt;
}

p.NewStyle46{
mso-style-name:"TOC 标题";
mso-style-parent:"标题 1";
mso-style-next:正文;
margin-top:20.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
text-indent:28.0000pt;
mso-char-indent-count:2.0000;
font-family:Cambria;
color:rgb(15,36,62);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:16.0000pt;
}

span.msoIns{
mso-style-type:export-only;
mso-style-name:"";
text-decoration:underline;
text-underline:single;
color:blue;
}

span.msoDel{
mso-style-type:export-only;
mso-style-name:"";
text-decoration:line-through;
color:red;
}

table.MsoNormalTable{
mso-style-name:普通表格;
mso-style-parent:"";
mso-style-noshow:yes;
mso-tstyle-rowband-size:0;
mso-tstyle-colband-size:0;
mso-padding-alt:0.0000pt 5.4000pt 0.0000pt 5.4000pt;
mso-para-margin:0pt;
mso-para-margin-bottom:.0001pt;
mso-pagination:widow-orphan;
font-family:'Times New Roman';
font-size:10.0000pt;
mso-ansi-language:#0400;
mso-fareast-language:#0400;
mso-bidi-language:#0400;
}
@page{mso-page-border-surround-header:no;
	mso-page-border-surround-footer:no;}@page Section0{
margin-top:72.0000pt;
margin-bottom:72.0000pt;
margin-left:90.0000pt;
margin-right:90.0000pt;
size:595.3000pt 841.9000pt;
layout-grid:15.6000pt;
}
div.Section0{page:Section0;}</style></head><body style="tab-interval:21pt;text-justify-trim:punctuation;" ><!--StartFragment--><div class="Section0"  style="layout-grid:15.6000pt;" ><p class=MsoNormal  align=center  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:center;mso-outline-level:1;line-height:21.0000pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:16.0000pt;mso-font-kerning:1.0000pt;" >企业基本情况调查表</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:16.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p><p class=MsoNormal  align=justify  style="text-indent:216.0000pt;mso-char-indent-count:24.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p><table class=MsoNormalTable  align=center  style="border-collapse:collapse;width:422.4500pt;margin-left:5.4000pt;mso-table-layout-alt:fixed;mso-padding-alt:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><tr><td width=110  valign=top  style="width:83.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=136  valign=top  style="width:102.2500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=166  valign=top  style="width:124.9000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=58  valign=top  style="width:44.2000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >表&nbsp;&nbsp;&nbsp;号：</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=90  valign=center  style="width:68.0000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=left  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:distribute-all-lines;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >Ｎ&nbsp;１</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >３</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >１</span><i><span style="font-family:宋体;font-style:italic;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span></i><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;表</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr><td width=110  valign=top  style="width:83.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=136  valign=top  style="width:102.2500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=166  valign=top  style="width:124.9000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=58  valign=center  style="width:44.2000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >制定机关：</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=90  valign=center  style="width:68.0000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=left  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:distribute-all-lines;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >国家统计局</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr><td width=110  valign=top  style="width:83.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=136  valign=top  style="width:102.2500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=166  valign=top  style="width:124.9000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=58  valign=center  style="width:44.2000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >文&nbsp;&nbsp;&nbsp;号：</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=90  valign=center  style="width:68.0000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=left  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:distribute-all-lines;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >国统字(2015)95号</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr><td width=110  valign=top  style="width:83.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=136  valign=top  style="width:102.2500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="font-family:宋体;font-size:11.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=166  valign=top  style="width:124.9000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:11.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['yupdatetime']); ?>年</span><span style="font-family:宋体;font-size:11.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=58  valign=center  style="width:44.2000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >有效期至：</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=90  valign=center  style="width:68.0000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=left  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:distribute-all-lines;line-height:12.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >２０１６年６月</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr></table><p class=MsoNormal  align=justify  style="text-indent:216.0000pt;mso-char-indent-count:24.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;line-height:0.7000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p><table class=MsoNormalTable  align=center  style="border-collapse:collapse;width:443.6000pt;margin-left:-35.5000pt;mso-table-layout-alt:fixed;mso-padding-alt:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;" ><tr style="height:21.4500pt;" ><td width=284  valign=center  colspan=3  style="width:213.3500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:1.0000pt solid windowtext;mso-border-top-alt:1.0000pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >01&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >单位详细名称</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['dwxxmc']); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></u><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=307  valign=center  colspan=3  style="width:230.2500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:1.0000pt solid windowtext;mso-border-top-alt:1.0000pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >0</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >2</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >组织机构代码</span><span style="font-family:宋体;font-size:14.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="font-family:宋体;font-size:14.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:8.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['zzjgdm']); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >统一</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >社会信用代码</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:8.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['shxydm']); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr style="height:23.4000pt;" ><td width=284  valign=center  colspan=3  style="width:213.3500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >03&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >法定代表人(单位负责人</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >)</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;<?php echo ($user['Company']['fddbr']); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></u><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=307  valign=center  colspan=3  style="width:230.2500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >04&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >联系电话</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >(</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >含区号</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >)<?php echo ($user['Company']['dianhua']); ?></span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >　　　　　　　　　　　　</span></u><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr style="height:25.5000pt;page-break-inside:avoid;" ><td width=284  valign=center  colspan=3  rowspan=2  style="width:213.3500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:none;;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.5000pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >0</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >5</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >单位所在地</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;</span></u><u><span style="font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span></u><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;&nbsp;&nbsp;</span></u><u><span style="font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ((isset($user['Company']['dwszd'][0]) && ($user['Company']['dwszd'][0] !== ""))?($user['Company']['dwszd'][0]):'湖北'); ?></span></u><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >省</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >(</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >自治区、直辖市</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >)</span><u><span style="font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span></u><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;&nbsp;</span></u><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;</span></u><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ((isset($user['Company']['dwszd'][1]) && ($user['Company']['dwszd'][1] !== ""))?($user['Company']['dwszd'][1]):'武汉'); ?></span></u><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >地</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >(</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >区、市、州、盟</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >)&nbsp;</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></u><u><span style="font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span></u><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['dwszd'][2]); ?></span></u><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >县</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >(</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >区、市、旗</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >)</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;</span></u><u><span style="font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span></u><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></u><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >乡</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >(</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >镇</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >)</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;&nbsp;</span></u><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;<?php echo ($user['Company']['dwszd'][3]); ?>&nbsp;</span></u><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >街</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >(</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >村</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >)</span><u><span style="font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span></u><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;&nbsp;&nbsp;</span></u><u><span style="font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span></u><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['dwszd'][4]); ?></span></u><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >门牌号</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=307  valign=center  colspan=3  style="width:230.2500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >0</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >6</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >区划代码（统计机构填写）&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9633;&#9633;&#9633;&#9633;&#9633;&#9633;</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr style="height:25.5000pt;page-break-inside:avoid;" ><td width=307  valign=center  colspan=3  style="width:230.2500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >0</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >7</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >邮政编码</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['yzbm']); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr style="height:19.8500pt;page-break-inside:avoid;" ><td width=591  valign=center  colspan=6  style="width:443.6000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >请于下列各选项后的&nbsp;</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9633;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;中打&#8220;&#8730;&#8221;</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr style="height:22.2500pt;" ><td width=284  valign=center  colspan=3  style="width:213.3500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >08</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >是否有出口业务</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;</span>
<?php if($user['Company']['sfck']==1): ?><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9312;是</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >●</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >　　&nbsp;&#9313;否</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >○</span>
<?php else: ?>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9312;是</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >○</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >　　&nbsp;&#9313;否</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >●</span><?php endif; ?>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=307  valign=center  colspan=3  style="width:230.2500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:1.0000pt solid windowtext;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >09&nbsp;是否为上市公司　　&nbsp;&nbsp;</span>

<?php if($user['Company']['sfss']==1): ?><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9312;是</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >●</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >　　&nbsp;&#9313;否</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >○</span>
<?php else: ?>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9312;是</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >○</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >　　&nbsp;&#9313;否</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >●</span><?php endif; ?>

<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr style="height:88.2500pt;page-break-inside:avoid;" ><td width=591  valign=center  colspan=6  style="width:443.6000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="margin-bottom:6.2000pt;mso-para-margin-bottom:0.4000gd;text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >1</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >0登记注册类型</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
<p class=MsoNormal  align=justify  style="margin-bottom:6.2000pt;mso-para-margin-bottom:0.4000gd;text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;内资&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><b><span style="mso-spacerun:'yes';font-family:黑体;mso-hansi-font-family:宋体;font-weight:bold;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;</span></b><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >港澳台商投资&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><b><span style="font-family:黑体;mso-hansi-font-family:宋体;font-weight:bold;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span></b><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >外商投资</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
<p class=MsoNormal  align=justify  style="text-indent:9.0000pt;mso-char-indent-count:1.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >110国有&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user[Company][djzclx]=='110'): ?>●<?php else: ?>○<?php endif; ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;159其他有限责任公司</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user[Company][djzclx]=='159'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;210与港澳台商合资经营&nbsp;&nbsp;<?php if($user[Company][djzclx]=='210'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;310中外合资经营&nbsp;<?php if($user[Company][djzclx]=='310'): ?>●<?php else: ?>○<?php endif; ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
<p class=MsoNormal  align=justify  style="text-indent:9.0000pt;mso-char-indent-count:1.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >120集体&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user[Company][djzclx]=='120'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;160股份有限公司&nbsp;&nbsp;&nbsp;&nbsp;<?php if($user[Company][djzclx]=='160'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;220与港澳台商合作经营&nbsp;&nbsp;<?php if($user[Company][djzclx]=='220'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;320中外合作经营&nbsp;<?php if($user[Company][djzclx]=='320'): ?>●<?php else: ?>○<?php endif; ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
<p class=MsoNormal  align=justify  style="text-indent:9.0000pt;mso-char-indent-count:1.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >130股份合作&nbsp;&nbsp;&nbsp;</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user[Company][djzclx]=='130'): ?>●<?php else: ?>○<?php endif; ?></span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;171私营独资&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user[Company][djzclx]=='171'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;230港澳台独资&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php if($user[Company][djzclx]=='230'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;330外资企业&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php if($user[Company][djzclx]=='330'): ?>●<?php else: ?>○<?php endif; ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
<p class=MsoNormal  align=justify  style="text-indent:9.0000pt;mso-char-indent-count:1.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >141国有联营&nbsp;&nbsp;&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user[Company][djzclx]=='141'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;172私营合伙&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php if($user[Company][djzclx]=='172'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;240港澳台商投资股份有限公司<?php if($user[Company][djzclx]=='240'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;340外商投资股份</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p><?php if($user[Company][djzclx]=='340'): ?>●<?php else: ?>○<?php endif; ?></span></p>
<p class=MsoNormal  align=justify  style="text-indent:9.0000pt;mso-char-indent-count:1.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >142集体联营&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php if($user[Company][djzclx]=='142'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;173私营有限责任公司<?php if($user[Company][djzclx]=='173'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;290其他港澳台投资有限公司<?php if($user[Company][djzclx]=='290'): ?>●<?php else: ?>○<?php endif; ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
<p class=MsoNormal  align=justify  style="text-indent:9.0000pt;mso-char-indent-count:1.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >143国有与集体联营&nbsp;<?php if($user[Company][djzclx]=='143'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;174私营股份有限公司<?php if($user[Company][djzclx]=='174'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;390其他外商投资&nbsp;<?php if($user[Company][djzclx]=='390'): ?>●<?php else: ?>○<?php endif; ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
<p class=MsoNormal  align=justify  style="text-indent:9.0000pt;mso-char-indent-count:1.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >149其他联营&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php if($user[Company][djzclx]=='149'): ?>●<?php else: ?>○<?php endif; ?>&nbsp;&nbsp;190其他&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php if($user[Company][djzclx]=='190'): ?>●<?php else: ?>○<?php endif; ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
<p class=MsoNormal  align=justify  style="text-indent:9.0000pt;mso-char-indent-count:1.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >151国有独资公司&nbsp;&nbsp;&nbsp;<?php if($user[Company][djzclx]=='151'): ?>●<?php else: ?>○<?php endif; ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
</td></tr>
<tr style="height:23.2000pt;page-break-inside:avoid;" ><td width=284  valign=center  colspan=3  style="width:213.3500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.5000pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >11&nbsp;是否为国有控股企业　&nbsp;&nbsp;</span>
<?php if($user['Company']['sfgykg']==1): ?><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9312;是</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >●</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >　　&nbsp;&#9313;否</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >○</span>
<?php else: ?>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9312;是</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >○</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >　　&nbsp;&#9313;否</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >●</span><?php endif; ?>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=307  valign=center  colspan=3  style="width:230.2500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:0.5000pt solid windowtext;mso-border-left-alt:0.5000pt solid windowtext;border-top:1.0000pt solid windowtext;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >1</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >2</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >单位规模&nbsp;</span>

<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9312;大型</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user['Company']['dwgm']==1): ?>●<?php else: ?>○<?php endif; ?>&nbsp;</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9313;中型</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user['Company']['dwgm']==2): ?>●<?php else: ?>○<?php endif; ?>&nbsp;</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9314;小型</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user['Company']['dwgm']==3): ?>●<?php else: ?>○<?php endif; ?>&nbsp;</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9315;微型</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($user['Company']['dwgm']==4): ?>●<?php else: ?>○<?php endif; ?>&nbsp;</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span>
</p></td></tr><tr style="height:23.2000pt;page-break-inside:avoid;" ><td width=591  valign=center  colspan=6  style="width:443.6000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >1</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >3&nbsp;行业代码（统计机构填写）　&nbsp;&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['hydm']); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr style="height:23.2000pt;page-break-inside:avoid;" ><td width=591  valign=center  colspan=6  style="width:443.6000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >14从业人员期末人数&nbsp;</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >　<?php echo ($user['Company']['qmcyrs']); ?></span></u><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >&nbsp;人</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr style="height:17.7500pt;" ><td width=591  valign=center  colspan=6  style="width:443.6000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:31.8750pt none rgb(255,255,255);mso-border-bottom-alt:31.8750pt none rgb(255,255,255);" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >1</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >5主要经济指标（不保留小数位）</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr style="height:15.4500pt;" ><td width=218  valign=center  style="width:163.7000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:31.8750pt none rgb(255,255,255);mso-border-right-alt:31.8750pt none rgb(255,255,255);border-top:none;;mso-border-top-alt:31.8750pt none rgb(255,255,255);border-bottom:31.8750pt none rgb(255,255,255);mso-border-bottom-alt:31.8750pt none rgb(255,255,255);" ><p class=MsoNormal  align=justify  style="text-indent:18.0000pt;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >营业收入&nbsp;</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >　<?php echo ($user['Company']['zyjjzb'][0]); ?></span></u><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >&nbsp;千元</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p></o:p></span></p></td><td width=191  valign=center  colspan=4  style="width:143.8000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-right:31.8750pt none rgb(255,255,255);mso-border-right-alt:31.8750pt none rgb(255,255,255);border-top:31.8750pt none rgb(255,255,255);mso-border-top-alt:31.8750pt none rgb(255,255,255);border-bottom:31.8750pt none rgb(255,255,255);mso-border-bottom-alt:31.8750pt none rgb(255,255,255);" ><p class=MsoNormal  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >其中：主营业务收入</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >　<?php echo ($user['Company']['zyjjzb'][1]); ?></span></u><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >&nbsp;千元</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p></o:p></span></p></td><td width=181  valign=center  style="width:136.1000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:31.8750pt none rgb(255,255,255);mso-border-top-alt:31.8750pt none rgb(255,255,255);border-bottom:31.8750pt none rgb(255,255,255);mso-border-bottom-alt:31.8750pt none rgb(255,255,255);" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >资产总计</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><?php echo ($user['Company']['zyjjzb'][2]); ?></span></u><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >千元</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p></o:p></span></p></td></tr><tr style="height:23.2000pt;page-break-inside:avoid;" ><td width=591  valign=center  colspan=6  style="width:443.6000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:0.2500pt solid windowtext;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >16主要业务活动(填写营业收入份额最大的三项业务活动或主要产品，营业收入所占份额不保留小数)</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p></o:p></span></p></td></tr><tr style="height:14.2000pt;page-break-inside:avoid;" ><td width=229  valign=center  colspan=2  style="width:172.0000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=center  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:center;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >业务活动(或主要产品)名称</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p></o:p></span></p></td><td width=106  valign=center  colspan=2  style="width:80.1500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:1.0000pt solid windowtext;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=center  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:center;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >行业代码</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p></o:p></span></p></td><td width=255  valign=center  colspan=2  style="width:191.4500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:1.0000pt solid windowtext;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=center  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:center;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" >营业收入所占份额约为(%)</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p></o:p></span></p></td></tr><tr style="height:14.2000pt;page-break-inside:avoid;" >
<td width=229  valign=center  colspan=2  style="width:172.0000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p><?php echo ($user['Company']['zyywhd'][0]); ?></o:p></span></p></td>
<td width=106  valign=center  colspan=2  style="width:80.1500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p><?php echo ($user['Company']['zyywhd'][1]); ?></o:p></span></p></td>
<td width=255  valign=center  colspan=2  style="width:191.4500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p><?php echo ($user['Company']['zyywhd'][2]); ?></o:p></span></p></td>
</tr>
<tr style="height:14.2000pt;page-break-inside:avoid;" >
<td width=229  valign=center  colspan=2  style="width:172.0000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p><?php echo ($user['Company']['zyywhd'][3]); ?></o:p></span></p></td>
<td width=106  valign=center  colspan=2  style="width:80.1500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p><?php echo ($user['Company']['zyywhd'][4]); ?></o:p></span></p></td>
<td width=255  valign=center  colspan=2  style="width:191.4500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p><?php echo ($user['Company']['zyywhd'][5]); ?></o:p></span></p></td></tr>
<tr style="height:14.2000pt;page-break-inside:avoid;" >
<td width=229  valign=center  colspan=2  style="width:172.0000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:1.0000pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p><?php echo ($user['Company']['zyywhd'][6]); ?></o:p></span></p></td>
<td width=106  valign=center  colspan=2  style="width:80.1500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:1.0000pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p><?php echo ($user['Company']['zyywhd'][7]); ?></o:p></span></p></td>
<td width=255  valign=center  colspan=2  style="width:191.4500pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:1.0000pt solid windowtext;" ><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-outline-level:1;mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;background:rgb(255,255,0);mso-highlight:rgb(255,255,0);" ><o:p><?php echo ($user['Company']['zyywhd'][8]); ?></o:p></span></p></td></tr>
</table><p class=MsoNormal  align=justify  style="text-indent:0.0000pt;mso-char-indent-count:0.0000;mso-pagination:none;text-align:justify;text-justify:inter-ideograph;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >联系人姓名：</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;<?php echo ($user['Company']['lxrxm']); ?>&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;职务：</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['zw']); ?>　　</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;&nbsp;&nbsp;电话：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user['Company']['lxdianhua']); ?></span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;报出日期：</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;<?php echo ($user['Company']['updatetime']); ?></span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></div><!--EndFragment--></body></html>