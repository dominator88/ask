<?php if (!defined('THINK_PATH')) exit();?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta http-equiv=Content-Type  content="text/html; charset=utf-8" ><meta name=ProgId  content=Word.Document ><meta name=Generator  content="Microsoft Word 14" ><meta name=Originator  content="Microsoft Word 14" ><title></title><!--[if gte mso 9]><xml><w:WordDocument><w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel><w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery><w:DisplayVerticalDrawingGridEvery>2</w:DisplayVerticalDrawingGridEvery><w:DocumentKind>DocumentNotSpecified</w:DocumentKind><w:DrawingGridVerticalSpacing>7.8 磅</w:DrawingGridVerticalSpacing><w:PunctuationKerning></w:PunctuationKerning><w:View>Web</w:View><w:Compatibility><w:DontGrowAutofit/><w:BalanceSingleByteDoubleByteWidth/><w:DoNotExpandShiftReturn/><w:UseFELayout/></w:Compatibility><w:Zoom>0</w:Zoom></w:WordDocument></xml><![endif]--><!--[if gte mso 9]><xml><w:LatentStyles DefLockedState="false"  DefUnhideWhenUsed="true"  DefSemiHidden="true"  DefQFormat="false"  DefPriority="99"  LatentStyleCount="260" >
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Normal" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="heading 9" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index 9" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="39"  SemiHidden="false"  Name="toc 9" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Normal Indent" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="footnote text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="annotation text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="header" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="footer" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="index heading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="caption" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="table of figures" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="envelope address" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="envelope return" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="footnote reference" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="annotation reference" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="line number" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="page number" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="endnote reference" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="endnote text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="table of authorities" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="macro" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="toa heading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Bullet 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Number 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Title" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Closing" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Signature" ></w:LsdException>
<w:LsdException Locked="false"  Priority="1"  SemiHidden="false"  Name="Default Paragraph Font" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text Indent" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Continue 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Message Header" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Subtitle" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Salutation" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Date" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text First Indent" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text First Indent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Note Heading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text Indent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Body Text Indent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Block Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Hyperlink" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="FollowedHyperlink" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Strong" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Emphasis" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Document Map" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Plain Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="E-mail Signature" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Normal (Web)" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Acronym" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Address" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Cite" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Code" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Definition" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Keyboard" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Preformatted" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Sample" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Typewriter" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="HTML Variable" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  QFormat="true"  Name="Normal Table" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="annotation subject" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="No List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Simple 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Simple 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Simple 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Classic 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Classic 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Classic 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Classic 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Colorful 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Colorful 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Colorful 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Columns 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Grid 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table List 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table 3D effects 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table 3D effects 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table 3D effects 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Contemporary" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Elegant" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Professional" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Subtle 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Subtle 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Web 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Web 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Web 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Balloon Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="59"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Table Theme" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 6" ></w:LsdException>
</w:LatentStyles></xml><![endif]--><style>
@font-face{
font-family:"Times New Roman";
}

@font-face{
font-family:"宋体";
}

@font-face{
font-family:"Calibri";
}

@font-face{
font-family:"Wingdings";
}

@font-face{
font-family:"Cambria";
}

@list l0:level1{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F09F;
mso-level-tab-stop:76.5000pt;
mso-level-number-position:left;
margin-left:76.5000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l0:level2{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F09F;
mso-level-tab-stop:69.0000pt;
mso-level-number-position:left;
margin-left:69.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l0:level3{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F075;
mso-level-tab-stop:90.0000pt;
mso-level-number-position:left;
margin-left:90.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l0:level4{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F06C;
mso-level-tab-stop:111.0000pt;
mso-level-number-position:left;
margin-left:111.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l0:level5{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F06E;
mso-level-tab-stop:132.0000pt;
mso-level-number-position:left;
margin-left:132.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l0:level6{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F075;
mso-level-tab-stop:153.0000pt;
mso-level-number-position:left;
margin-left:153.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l0:level7{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F06C;
mso-level-tab-stop:174.0000pt;
mso-level-number-position:left;
margin-left:174.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l0:level8{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F06E;
mso-level-tab-stop:195.0000pt;
mso-level-number-position:left;
margin-left:195.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l0:level9{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F075;
mso-level-tab-stop:216.0000pt;
mso-level-number-position:left;
margin-left:216.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l1:level1{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F09F;
mso-level-tab-stop:49.5000pt;
mso-level-number-position:left;
margin-left:49.5000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l1:level2{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F06E;
mso-level-tab-stop:42.0000pt;
mso-level-number-position:left;
margin-left:42.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l1:level3{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F075;
mso-level-tab-stop:63.0000pt;
mso-level-number-position:left;
margin-left:63.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l1:level4{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F06C;
mso-level-tab-stop:84.0000pt;
mso-level-number-position:left;
margin-left:84.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l1:level5{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F06E;
mso-level-tab-stop:105.0000pt;
mso-level-number-position:left;
margin-left:105.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l1:level6{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F075;
mso-level-tab-stop:126.0000pt;
mso-level-number-position:left;
margin-left:126.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l1:level7{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F06C;
mso-level-tab-stop:147.0000pt;
mso-level-number-position:left;
margin-left:147.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l1:level8{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F06E;
mso-level-tab-stop:168.0000pt;
mso-level-number-position:left;
margin-left:168.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

@list l1:level9{
mso-level-number-format:bullet;
mso-level-suffix:tab;
mso-level-text:\F075;
mso-level-tab-stop:189.0000pt;
mso-level-number-position:left;
margin-left:189.0000pt;text-indent:-21.0000pt;font-family:Wingdings;}

p.MsoNormal{
mso-style-name:正文;
mso-style-parent:"";
margin:0pt;
margin-bottom:.0001pt;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:'Times New Roman';
font-size:10.5000pt;
mso-font-kerning:1.0000pt;
}

h1{
mso-style-name:"标题 1";
mso-style-next:正文;
margin-top:20.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
mso-outline-level:1;
font-family:Cambria;
color:rgb(15,36,62);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:16.0000pt;
mso-font-kerning:1.0000pt;
}

h2{
mso-style-name:"标题 2";
mso-style-next:正文;
margin-top:6.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
mso-outline-level:2;
font-family:Cambria;
color:rgb(23,54,93);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:10.5000pt;
mso-font-kerning:1.0000pt;
}

h3{
mso-style-name:"标题 3";
mso-style-next:正文;
margin-top:6.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
mso-outline-level:3;
font-family:Cambria;
color:rgb(31,73,125);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:12.0000pt;
mso-font-kerning:1.0000pt;
}

h4{
mso-style-name:"标题 4";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:5.0000pt;
mso-add-space:auto;
border-bottom:1.0000pt solid rgb(113,160,220);
mso-border-bottom-alt:0.5000pt solid rgb(113,160,220);
padding:0pt 0pt 1pt 0pt ;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
mso-outline-level:4;
font-family:Cambria;
color:rgb(48,113,195);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:10.0000pt;
mso-font-kerning:1.0000pt;
}

h5{
mso-style-name:"标题 5";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:5.0000pt;
mso-add-space:auto;
border-bottom:1.0000pt solid rgb(84,141,212);
mso-border-bottom-alt:0.5000pt solid rgb(84,141,212);
padding:0pt 0pt 1pt 0pt ;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
mso-outline-level:5;
font-family:Cambria;
color:rgb(48,113,195);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:10.0000pt;
mso-font-kerning:1.0000pt;
}

h6{
mso-style-name:"标题 6";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:5.0000pt;
mso-add-space:auto;
border-bottom:1.0000pt dotted rgb(147,137,83);
mso-border-bottom-alt:1.0000pt dotted rgb(147,137,83);
padding:0pt 0pt 1pt 0pt ;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
mso-outline-level:6;
font-family:Cambria;
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:10.0000pt;
mso-font-kerning:1.0000pt;
}

p.MsoHeading7{
mso-style-name:"标题 7";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:5.0000pt;
mso-add-space:auto;
border-bottom:1.0000pt dotted rgb(147,137,83);
mso-border-bottom-alt:1.0000pt dotted rgb(147,137,83);
padding:0pt 0pt 1pt 0pt ;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
mso-outline-level:7;
font-family:Cambria;
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:8.0000pt;
mso-font-kerning:1.0000pt;
}

p.MsoHeading8{
mso-style-name:"标题 8";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
mso-outline-level:8;
font-family:Cambria;
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:8.0000pt;
mso-font-kerning:1.0000pt;
}

p.Msoheading9{
mso-style-name:"标题 9";
mso-style-next:正文;
margin-top:10.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
mso-outline-level:9;
font-family:Cambria;
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:8.0000pt;
mso-font-kerning:1.0000pt;
}

span.10{
font-family:'Times New Roman';
}

span.15{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(54,95,145);
font-variant:small-caps;
font-size:10.0000pt;
}

span.16{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:8.0000pt;
}

span.17{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:8.0000pt;
}

span.18{
font-family:'Times New Roman';
letter-spacing:0.0000pt;
font-weight:bold;
}

span.19{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
font-size:8.0000pt;
}

span.20{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(31,73,125);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:12.0000pt;
}

span.21{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:1.0000pt;
font-variant:small-caps;
}

span.22{
font-family:'Times New Roman';
color:rgb(90,90,90);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
}

span.23{
font-family:'Times New Roman';
font-size:9.0000pt;
}

span.24{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(15,36,62);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:16.0000pt;
}

span.25{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(48,113,195);
letter-spacing:1.0000pt;
font-variant:small-caps;
}

span.26{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(23,54,93);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:14.0000pt;
}

span.27{
font-family:'Times New Roman';
color:rgb(90,90,90);
font-style:italic;
font-size:10.0000pt;
}

span.28{
font-family:'Times New Roman';
color:rgb(79,129,189);
letter-spacing:2.0000pt;
font-weight:bold;
font-variant:small-caps;
}

span.29{
font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:0.2500pt;
font-variant:small-caps;
font-size:14.0000pt;
}

span.30{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(48,113,195);
letter-spacing:1.0000pt;
font-weight:bold;
font-variant:small-caps;
}

span.31{
font-family:'Times New Roman';
font-size:9.0000pt;
}

span.32{
font-family:Cambria;
mso-fareast-font-family:宋体;
mso-bidi-font-family:'Times New Roman';
color:rgb(23,54,93);
letter-spacing:0.2500pt;
font-variant:small-caps;
font-size:36.0000pt;
}

span.33{
font-family:Cambria;
mso-fareast-font-family:宋体;
color:rgb(23,54,93);
letter-spacing:0.5000pt;
font-weight:bold;
text-decoration:underline;
text-underline:single;
font-variant:small-caps;
}

span.34{
font-family:Cambria;
mso-fareast-font-family:宋体;
color:rgb(90,90,90);
letter-spacing:1.0000pt;
font-style:italic;
font-variant:small-caps;
}

span.35{
font-family:'Times New Roman';
color:rgb(90,90,90);
font-variant:small-caps;
}

span.36{
font-family:Cambria;
mso-fareast-font-family:宋体;
color:rgb(23,54,93);
letter-spacing:1.0000pt;
font-weight:bold;
font-style:italic;
font-variant:small-caps;
}

p.MsoHeader{
mso-style-name:页眉;
mso-style-noshow:yes;
margin:0pt;
margin-bottom:.0001pt;
border-bottom:1.0000pt solid windowtext;
mso-border-bottom-alt:0.7500pt solid windowtext;
padding:0pt 0pt 1pt 0pt ;
layout-grid-mode:char;
mso-pagination:none;
text-align:center;
font-family:'Times New Roman';
font-size:9.0000pt;
mso-font-kerning:1.0000pt;
}

p.NewStyle38{
mso-style-name:"TOC 标题";
mso-style-parent:"标题 1";
mso-style-next:正文;
margin-top:20.0000pt;
margin-bottom:3.0000pt;
mso-add-space:auto;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:Cambria;
color:rgb(15,36,62);
letter-spacing:1.0000pt;
font-variant:small-caps;
font-size:16.0000pt;
mso-font-kerning:1.0000pt;
}

p.MsoCaption{
mso-style-name:题注;
mso-style-next:正文;
margin:0pt;
margin-bottom:.0001pt;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:'Times New Roman';
color:rgb(31,73,125);
letter-spacing:0.5000pt;
font-weight:bold;
font-variant:small-caps;
font-size:9.0000pt;
mso-font-kerning:1.0000pt;
}

p.NewStyle40{
mso-style-name:引用;
mso-style-next:正文;
margin:0pt;
margin-bottom:.0001pt;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:'Times New Roman';
color:rgb(90,90,90);
font-style:italic;
font-size:10.0000pt;
mso-font-kerning:1.0000pt;
}

p.MsoFooter{
mso-style-name:页脚;
mso-style-noshow:yes;
margin:0pt;
margin-bottom:.0001pt;
layout-grid-mode:char;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:'Times New Roman';
font-size:9.0000pt;
mso-font-kerning:1.0000pt;
}

p.MsoSubtitle{
mso-style-name:副标题;
mso-style-next:正文;
margin-bottom:30.0000pt;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:'Times New Roman';
color:rgb(147,137,83);
letter-spacing:0.2500pt;
font-variant:small-caps;
font-size:10.5000pt;
mso-font-kerning:1.0000pt;
}

p.MsoTitle{
mso-style-name:标题;
mso-style-next:正文;
margin:0pt;
margin-bottom:.0001pt;
mso-add-space:auto;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:Cambria;
color:rgb(23,54,93);
letter-spacing:0.2500pt;
font-variant:small-caps;
font-size:36.0000pt;
mso-font-kerning:1.0000pt;
}

p.NewStyle44{
mso-style-name:无间隔;
margin:0pt;
margin-bottom:.0001pt;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:'Times New Roman';
font-size:10.5000pt;
mso-font-kerning:1.0000pt;
}

p.NewStyle45{
mso-style-name:列出段落;
margin-left:36.0000pt;
mso-add-space:auto;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:'Times New Roman';
font-size:10.5000pt;
mso-font-kerning:1.0000pt;
}

p.NewStyle46{
mso-style-name:明显引用;
mso-style-next:正文;
margin-right:21.6000pt;
margin-left:125.3000pt;
border-top:1.0000pt solid rgb(123,160,205);
mso-border-top-alt:0.5000pt solid rgb(123,160,205);
border-right:1.5000pt solid rgb(54,95,145);
mso-border-right-alt:1.5000pt solid rgb(54,95,145);
border-bottom:1.5000pt solid rgb(54,95,145);
mso-border-bottom-alt:1.5000pt solid rgb(54,95,145);
border-left:1.0000pt solid rgb(123,160,205);
mso-border-left-alt:0.5000pt solid rgb(123,160,205);
padding:12pt 15pt 10pt 15pt ;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
line-height:125%;
font-family:Cambria;
color:rgb(54,95,145);
font-variant:small-caps;
font-size:10.0000pt;
mso-font-kerning:1.0000pt;
}

span.msoIns{
mso-style-type:export-only;
mso-style-name:"";
text-decoration:underline;
text-underline:single;
color:blue;
}

span.msoDel{
mso-style-type:export-only;
mso-style-name:"";
text-decoration:line-through;
color:red;
}

table.MsoNormalTable{
mso-style-name:普通表格;
mso-style-parent:"";
mso-style-noshow:yes;
mso-tstyle-rowband-size:0;
mso-tstyle-colband-size:0;
mso-padding-alt:0.0000pt 5.4000pt 0.0000pt 5.4000pt;
mso-para-margin:0pt;
mso-para-margin-bottom:.0001pt;
mso-pagination:widow-orphan;
font-family:'Times New Roman';
font-size:10.0000pt;
mso-ansi-language:#0400;
mso-fareast-language:#0400;
mso-bidi-language:#0400;
}
@page{mso-page-border-surround-header:no;
	mso-page-border-surround-footer:no;}@page Section0{
margin-top:53.8500pt;
margin-bottom:48.2000pt;
margin-left:62.3500pt;
margin-right:62.3500pt;
size:595.3000pt 841.9000pt;
layout-grid:15.6000pt;
}
div.Section0{page:Section0;}@page Section1{
margin-top:72.0000pt;
margin-bottom:72.0000pt;
margin-left:90.0000pt;
margin-right:90.0000pt;
size:595.3000pt 841.9000pt;
layout-grid:15.6000pt;
}
div.Section1{page:Section1;}</style></head>
<body style="tab-interval:21pt;text-justify-trim:punctuation;" ><!--StartFragment-->
<div class="Section0"  style="layout-grid:15.6000pt;" ><p class=MsoNormal  align=center  style="text-indent:32.0000pt;text-align:center;mso-outline-level:1;mso-line-height-alt:0pt;" >
<span style="mso-spacerun:'yes';font-family:宋体;font-size:16.0000pt;mso-font-kerning:1.0000pt;" >制造业采购经理调查问卷</span>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:16.0000pt;mso-font-kerning:1.0000pt;" >
<o:p></o:p></span></p>
<p class=MsoNormal  style="text-indent:189.2000pt;mso-char-indent-count:22.0000;mso-outline-level:1;mso-line-height-alt:12pt;" >
<span style="mso-spacerun:'yes';font-family:宋体;letter-spacing:-0.2000pt;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p>
<table class=MsoNormalTable  style="border-collapse:collapse;width:470.6000pt;margin-left:5.4000pt;mso-table-layout-alt:fixed;mso-padding-alt:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" >
<tr>
<td width=125  valign=top  style="width:94.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" >
<p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td>
<td width=154  valign=top  style="width:115.8500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" >
<p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td>
<td width=188  valign=top  style="width:141.5500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=56  valign=top  style="width:42.0000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >表&nbsp;&nbsp;&nbsp;&nbsp;号：</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=102  valign=center  style="width:77.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=left  style="text-align:justify;text-justify:distribute-all-lines;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;letter-spacing:0.3000pt;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >Ｎ&nbsp;２</span><span style="font-family:宋体;letter-spacing:0.3000pt;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="font-family:宋体;letter-spacing:0.3000pt;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >４</span><span style="font-family:宋体;letter-spacing:0.3000pt;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;letter-spacing:0.3000pt;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >１　表</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr><td width=125  valign=top  style="width:94.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=154  valign=top  style="width:115.8500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=188  valign=top  style="width:141.5500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=56  valign=center  style="width:42.0000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >制定机关：</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=102  valign=center  style="width:77.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=left  style="text-align:justify;text-justify:distribute-all-lines;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >国家统计局</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr><td width=125  valign=top  style="width:94.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=154  valign=top  style="width:115.8500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=188  valign=top  style="width:141.5500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=56  valign=center  style="width:42.0000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >文&nbsp;&nbsp;&nbsp;&nbsp;号：</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=102  valign=center  style="width:77.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=left  style="text-align:justify;text-justify:distribute-all-lines;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >国统字(2015)95号</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr><tr><td width=125  valign=top  style="width:94.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=154  valign=top  style="width:115.8500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p></td><td width=188  valign=top  style="width:141.5500pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo (date('Y年m月',$questionInfo[reply][createtime])); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=56  valign=center  style="width:42.0000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >有效期至：</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=102  valign=center  style="width:77.1000pt;padding:0.0000pt 0.0000pt 0.0000pt 0.0000pt ;" ><p class=MsoNormal  align=left  style="text-align:justify;text-justify:distribute-all-lines;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;letter-spacing:-0.2000pt;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >２０１７年１月</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr></table><p class=MsoNormal  style="mso-outline-level:1;mso-line-height-alt:0pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:5.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p><table class=MsoNormalTable  align=center  style="border-collapse:collapse;width:486.0000pt;mso-table-layout-alt:fixed;mso-padding-alt:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;" ><tr style="height:11.3500pt;page-break-inside:avoid;" ><td width=341  valign=center  style="width:255.8000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-right:1.0000pt solid windowtext;mso-border-right-alt:0.2500pt solid windowtext;border-top:1.0000pt solid windowtext;mso-border-top-alt:1.0000pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >A单位详细名称</span><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;<?php echo ($user["Company"]["dwxxmc"]); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></u><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td><td width=306  valign=center  style="width:230.2000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-left:none;;mso-border-left-alt:none;;border-top:1.0000pt solid windowtext;mso-border-top-alt:1.0000pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >B&nbsp;组织机构代码</span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:7.5000pt;mso-font-kerning:1.0000pt;" ><a name="OLE_LINK1" ><?php echo ($user["Company"]["zzjgdm"]); ?></a></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&nbsp;&nbsp;</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >统一</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >社会信用代码</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:7.5000pt;mso-font-kerning:1.0000pt;" ><?php echo ($user[Company][shxydm]); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr>
<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$d): $mod = ($i % 2 );++$i; if($d['qtype'] == 'text'): ?><tr style="height:11.3500pt;page-break-inside:avoid;" ><td width=648  valign=center  colspan=2  style="width:486.0000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:none;;mso-border-top-alt:0.5000pt dashed windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($d["tihao"]); ?> <?php echo ($d["qname"]); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
 <?php if(is_array($d['options'])): foreach($d['options'] as $k=>$option): ?><p class=MsoNormal  style="margin-left:42.6000pt;text-indent:-18.0000pt;mso-line-height-alt:12pt;mso-list:l0 level2 lfo1;" ><?php echo (trim($option[text])); ?><u><span style="mso-spacerun:'yes';font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($option[value]); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></u><u><span style="font-family:宋体;text-decoration:underline;text-underline:single;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></u></p><?php endforeach; endif; ?>


</td></tr>

<?php elseif($d['qtype'] == 'radio'): ?>

<tr style="height:11.3500pt;page-break-inside:avoid;" >
<td width=648  valign=center  colspan=2  style="width:486.0000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt dashed windowtext;mso-border-bottom-alt:0.5000pt dashed windowtext;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($d["tihao"]); ?> </span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($d["qname"]); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p><p class=MsoNormal  style="text-indent:54.0000pt;mso-char-indent-count:6.0000;mso-line-height-alt:12pt;" >
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >

                        <?php if(is_array($d['options'])): foreach($d['options'] as $k=>$option): if($option['text'] != ''): if($option[selected]==1): ?>●<?php else: ?>○<?php endif; ?>&nbsp;<?php echo ($option['text']); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php endif; endforeach; endif; ?>

</span>
<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></td></tr>






 <?php elseif($d['qtype'] == 'checkbox'): ?>
<tr style="height:8.5000pt;page-break-inside:avoid;" ><td width=648  valign=center  colspan=2  style="width:486.0000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($d["tihao"]); ?> <?php echo ($d["qname"]); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>

<p class=MsoNormal  style="mso-line-height-alt:12pt;" >
 <?php if(is_array($d['options'])): foreach($d['options'] as $k=>$option): if($option[type]=='checkbox'): ?><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >

<?php if($option[selected]==1): ?>●<?php else: ?>○<?php endif; ?>&nbsp; <?php echo ($option['text']); ?>&nbsp;&nbsp;&nbsp;&nbsp;</span>
 <?php elseif($option[type]=='checkbox_othertext'): ?>
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php if($option[selected]==1): ?>●<?php else: ?>○<?php endif; ?>其他&nbsp;（请具体说明）：<?php echo ($option["text"]); ?>_</span><?php endif; endforeach; endif; ?>
<!--span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
<p class=MsoNormal  style="mso-line-height-alt:12pt;" >
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9315;&nbsp;&#9633;&nbsp;运输成本上涨&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9316;&nbsp;&#9633;&nbsp;劳动力成本上涨&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9317;&nbsp;&#9633;&nbsp;能源等原材料供应紧张&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>

<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>

<p class=MsoNormal  style="mso-line-height-alt:12pt;" >
<span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9318;&nbsp;&#9633;&nbsp;劳动力供应不足&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9319;&nbsp;&#9633;&nbsp;人民币汇率波动&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#9320;&nbsp;</span>
<span style="mso-spacerun:'yes';font-family:宋体;mso-ascii-font-family:'Times New Roman';mso-hansi-font-family:'Times New Roman';font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#9633;&nbsp;</span-->



<span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span>
</p>

</td></tr>
 <?php elseif($d['qtype'] == 'checkbox_othertext'): ?>
 <tr style="height:8.5000pt;page-break-inside:avoid;" ><td width=648  valign=center  colspan=2  style="width:486.0000pt;padding:0.0000pt 5.4000pt 0.0000pt 5.4000pt ;border-top:none;;mso-border-top-alt:0.2500pt solid windowtext;border-bottom:1.0000pt solid windowtext;mso-border-bottom-alt:0.2500pt solid windowtext;" ><p class=MsoNormal  style="mso-line-height-alt:12pt;" ><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><?php echo ($d["tihao"]); ?> <?php echo ($d["qname"]); ?></span><span style="font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p>
 </td></tr><?php endif; endforeach; endif; else: echo "" ;endif; ?>


</table>
<p class=MsoNormal  style="mso-layout-grid-align:none;layout-grid-mode:char;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >采购经理：&nbsp;<?php echo ($user["realname"]); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;电话：&nbsp;&nbsp;<?php echo ($user["telephone"]); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;报出日期：<?php if($questionInfo[reply][createtime]!=''): echo (date('Y年m月d日',$questionInfo[reply][createtime])); endif; ?></span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p><p class=MsoNormal  style="mso-layout-grid-align:none;layout-grid-mode:char;mso-line-height-alt:12pt;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p>&nbsp;</o:p></span></p><p class=MsoNormal  style="mso-layout-grid-align:none;layout-grid-mode:char;line-height:10.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >说明：1</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >.</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >本表由制造业企业采购(或供应)经理或主管采购(或供应)业务的总经理填报，并通过</span><span style="mso-spacerun:'yes';font-family:宋体;mso-hansi-font-family:'Times New Roman';font-size:9.0000pt;mso-font-kerning:1.0000pt;" >网上直报或移动终端</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >报送。</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p><p class=MsoNormal  style="text-indent:27.0000pt;mso-char-indent-count:3.0000;mso-layout-grid-align:none;layout-grid-mode:char;line-height:10.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;mso-hansi-font-family:'Times New Roman';font-size:9.0000pt;mso-font-kerning:1.0000pt;" >2</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >.</span><span style="mso-spacerun:'yes';font-family:宋体;mso-hansi-font-family:'Times New Roman';font-size:9.0000pt;mso-font-kerning:1.0000pt;" >本表为月度报表，报送时间为当月22</span><span style="mso-spacerun:'yes';font-family:宋体;font-size:9.0000pt;mso-font-kerning:1.0000pt;" >&#8212;</span><span style="mso-spacerun:'yes';font-family:宋体;mso-hansi-font-family:'Times New Roman';font-size:9.0000pt;mso-font-kerning:1.0000pt;" >25日（16：00前）。</span><span style="mso-spacerun:'yes';font-family:宋体;mso-hansi-font-family:'Times New Roman';font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p><p class=MsoNormal  style="margin-left:36.1000pt;mso-para-margin-left:2.5800gd;text-indent:-9.0000pt;mso-char-indent-count:-1.0000;mso-layout-grid-align:none;layout-grid-mode:char;line-height:10.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;mso-hansi-font-family:'Times New Roman';font-size:9.0000pt;mso-font-kerning:1.0000pt;" >3.选项的界限：&#8220;基本持平&#8221;、&#8220;变化不大&#8221;或&#8220;差别不大&#8221;选项的界限主要由企业采购经理根据自己平时的经验进行判断。</span><span style="mso-spacerun:'yes';font-family:宋体;mso-hansi-font-family:'Times New Roman';font-size:9.0000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p><p class=MsoNormal  style="margin-left:36.1000pt;mso-para-margin-left:2.5800gd;text-indent:-9.0000pt;mso-char-indent-count:-1.0000;mso-layout-grid-align:none;layout-grid-mode:char;line-height:10.0000pt;mso-line-height-rule:exactly;" ><span style="mso-spacerun:'yes';font-family:宋体;mso-hansi-font-family:'Times New Roman';font-size:9.0000pt;mso-font-kerning:1.0000pt;" >4.对比期的确定：对于流量问题（时期指标，如生产量、采购量等），对比期为上个月；对于存量问题（时点指标，如库存量、人员等），对比期为一个月前。</span></p></div>
<span style="mso-spacerun:'yes';font-family:'Times New Roman';font-size:10.5000pt;mso-font-kerning:1.0000pt;" ><br clear=all style='page-break-before:always;mso-break-type:section-break'></span>
<div class="Section1"  style="layout-grid:15.6000pt;" ><p class=MsoNormal ><span style="mso-spacerun:'yes';font-family:'Times New Roman';font-size:10.5000pt;mso-font-kerning:1.0000pt;" ><o:p></o:p></span></p></div><!--EndFragment--></body></html>