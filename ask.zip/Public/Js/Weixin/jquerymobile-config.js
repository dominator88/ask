/**
 * 对JqueryMobile做些配置调整
 */
$.mobile.page.prototype.options.theme = "b";
$.mobile.page.prototype.options.domCache = false;
$.mobile.buttonMarkup.hoverDelay = false;
